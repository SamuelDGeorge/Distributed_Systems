package StringProcessors;

public class Plus extends Number
{
	public Plus(String input)
	{
		super(input, "Plus Number");
	}
}