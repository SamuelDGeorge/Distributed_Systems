package StringProcessors;

public class Redo extends Word
{
	public Redo(String input)
	{
		super(input, "Command");
	}
}