package Graphics;

public interface Mailbox extends LineAndShape
{
	public Shape createShape();
}
