package Graphics;

public interface Avatar extends LineAndShape
{
	public Shape createShape();
}
