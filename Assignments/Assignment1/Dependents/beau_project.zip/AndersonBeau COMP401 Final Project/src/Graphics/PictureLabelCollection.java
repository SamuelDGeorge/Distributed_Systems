package Graphics;

public interface PictureLabelCollection extends LabelCollection<PictureLabel>
{

}
