package util;

import java.beans.PropertyChangeListener;

public interface PropertyListenerRegisterer {
	public void addPropertyChangeListener(PropertyChangeListener arg0);
}
