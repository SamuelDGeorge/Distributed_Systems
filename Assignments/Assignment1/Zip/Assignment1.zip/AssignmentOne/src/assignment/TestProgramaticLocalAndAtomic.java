package assignment;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Scanner;

import CommandObjects.RemoteOperations;
import clients.BeauClient;
import nioextend.BroadcastingNioServer;
import servers.EchoingServerStarter;
import util.trace.TraceableInfo;
import util.trace.Tracer;

public class TestProgramaticLocalAndAtomic {
	public static void main(String[] args) throws IOException, InterruptedException {
		//Set up trace settings
		//Do Not show warings in OE
		Tracer.showWarnings(false);
		//Show traceables
		Tracer.showInfo(false);
				
		//Set up the Tracer to show status when it is in any of these classes, went with the client and the server. 
		//rest is housekeeping
		Tracer.setKeywordPrintStatus(BeauClient.class, true);
		Tracer.setKeywordPrintStatus(BroadcastingNioServer.class, true);
		Tracer.setKeywordPrintStatus(RemoteOperations.class, true);
		Tracer.setDisplayThreadName(true);
		TraceableInfo.setPrintTraceable(true);
		TraceableInfo.setPrintTime(true);
				
		//Begin by starting up a server. 
		EchoingServerStarter server = new EchoingServerStarter(null,9090);
		server.startServer();
		new BeauClient(InetAddress.getByName("localhost"),9090);
		BeauClient toManipulateTwo = new BeauClient(InetAddress.getByName("localhost"),9090);
		BeauClient toManipulateOne = new BeauClient(InetAddress.getByName("localhost"),9090);
		
		Object lock = new Object();
		
		synchronized (lock) {
			lock.wait(2000);
		}

		System.out.println("Ready to do demo of local, press enter to proceed");
		Scanner input = new Scanner(System.in);
		input.nextLine();
		
		toManipulateOne.setLocalMode(true);
		int backAndForth = 0;
		while (backAndForth < 10) {
			toManipulateOne.doCommand("take 1");
			for (int i = 0; i < 200; i++) {
				toManipulateOne.doCommand("move 1 0");
				
			}
	
			for (int i = 0; i < 200; i++) {
				toManipulateOne.doCommand("move -1 0");
			}
			
			backAndForth++;
		}
		
		
		toManipulateOne.setLocalMode(false);
		System.out.println("Ready to do atomic, press enter to proceed");
		input.nextLine();
		backAndForth = 0;
		toManipulateOne.doCommand("move 120 -75");
		
		synchronized (lock) {
			lock.wait(2000);
		}
		
		while (backAndForth < 10) {
			toManipulateOne.doCommand("take 1");
			for (int i = 0; i < 100; i++) {
				toManipulateOne.doCommand("move 1 0");
				toManipulateTwo.doCommand("move 1 0");
				
			}
	
			for (int i = 0; i < 100; i++) {
				toManipulateOne.doCommand("move -1 0");
				toManipulateTwo.doCommand("move -1 0");
			}
			
			backAndForth++;
		}
		
		System.out.println("Press enter to Exit");
		input.nextLine();
		System.exit(0);
		
		
	}
}
