package assignment;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Scanner;

import CommandObjects.RemoteOperations;
import clients.BeauClient;
import nioextend.BroadcastingNioServer;
import servers.EchoingServerStarter;
import util.trace.TraceableInfo;
import util.trace.Tracer;

public class TestGui {
	public static void main(String[] args) throws IOException {
		//Set up trace settings
		//Do Not show warings in OE
		Tracer.showWarnings(false);
		//Show traceables
		Tracer.showInfo(false);
				
		//Set up the Tracer to show status when it is in any of these classes, went with the client and the server. 
		//rest is housekeeping
		Tracer.setKeywordPrintStatus(BeauClient.class, true);
		Tracer.setKeywordPrintStatus(BroadcastingNioServer.class, true);
		Tracer.setKeywordPrintStatus(RemoteOperations.class, true);
		Tracer.setDisplayThreadName(true);
		TraceableInfo.setPrintTraceable(true);
		TraceableInfo.setPrintTime(true);
				
		//Begin by starting up a server. 
		EchoingServerStarter server = new EchoingServerStarter(null,9090);
		server.startServer();
		BeauClient toManipulate = new BeauClient(InetAddress.getByName("localhost"),9090);
		new BeauClient(InetAddress.getByName("localhost"),9090);
		new BeauClient(InetAddress.getByName("localhost"),9090);
		
		
		//Gui interaction portion
		System.out.println("Welcome to client manipulator.");
		System.out.println("Control one client to do commands or do local vs global mode");
		System.out.println("Type: L for Local, G for Global, or anything else to send as Command.");
		System.out.println("Type End to exit program");
		String input = "Default";
		Scanner scan = new Scanner(System.in);
		while (true) {
			input = scan.nextLine();
			if(input.equals("G")) {
				System.out.println("Demo In Global Mode");
				toManipulate.setLocalMode(false);
			} else if (input.equals("L")) {
				System.out.println("Demo In Local Mode");
				toManipulate.setLocalMode(true);
			} else if (!input.equals("End")){
				toManipulate.doCommand(input);
			} else {
				System.exit(0);
			}
		}
		
	}
}
