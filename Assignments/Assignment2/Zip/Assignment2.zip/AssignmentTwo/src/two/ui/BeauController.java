package two.ui;

public interface BeauController {
	public void setText(String text);
	public void setSelected(String mode);
}
