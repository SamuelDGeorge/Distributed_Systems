package two.server;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import two.clients.Client;


public class BasicBeauRMIServer implements BeauRMIServer {
	private Registry serverRegistry;
	private List<Client> clientlist;
	
	public BasicBeauRMIServer(String serverName) {
		this.clientlist = new ArrayList<Client>();
		try {
			this.serverRegistry = LocateRegistry.createRegistry(REGISTRY_PORT_NAME);	
			UnicastRemoteObject.exportObject(this, 0);
			this.serverRegistry.rebind(serverName, this);
		} catch (RemoteException e) {
			System.out.println("Failed to create server!");
			e.printStackTrace();
		}

	}

	
	public void join(String remoteName) throws RemoteException {
		try {
			Client toAdd = (Client) this.serverRegistry.lookup(remoteName);
			this.clientlist.add(toAdd);
		} catch (NotBoundException e) {
			System.out.println("Unable to Find your proxy. Please Make sure you unicast yourself");
			e.printStackTrace();
		}
		
	}

	
	public synchronized void EchoString(String sourceClientName, String toEcho) throws RemoteException {
		for (int i = 0; i < this.clientlist.size(); i++) {
			Client current = this.clientlist.get(i);
			current.processCommand(sourceClientName, toEcho);
		}
		
	}

	
	public synchronized void setClientModes(String mode) throws RemoteException {
		if("local".equals(mode)) {
			for (int i =0; i < this.clientlist.size();i++) {
				Client currentClient = this.clientlist.get(i);
				currentClient.setModeLocal();
			}
		} else if ("non-atomic".equals(mode)) {
			for (int i =0; i < this.clientlist.size();i++) {
				Client currentClient = this.clientlist.get(i);
				currentClient.setModeNonAtomic();
			}
		} else if ("atomic".equals(mode)) {
			for (int i =0; i < this.clientlist.size();i++) {
				Client currentClient = this.clientlist.get(i);
				currentClient.setModeAtomic();
			}
		} else {
			System.out.println("Invalid Mode");
		}
		
	}
	
	
	
}
