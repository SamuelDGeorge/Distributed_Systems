package two.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface BeauRMIServer extends Remote{
	static int REGISTRY_PORT_NAME = 4999;
	static String REGISTRY_HOST_NAME = "localhost";
	public void join(String remoteName) throws RemoteException;
	public void EchoString(String sourceClientName,String toEcho) throws RemoteException;
	public void setClientModes(String mode) throws RemoteException;
	
}
