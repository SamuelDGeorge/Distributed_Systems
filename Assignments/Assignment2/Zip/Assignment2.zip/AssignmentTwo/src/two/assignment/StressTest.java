package two.assignment;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

import two.clients.Client;
import two.clients.RMIClient;
import two.server.BasicBeauRMIServer;
import util.trace.Tracer;

public class StressTest {
	public static void main(String[] args) throws RemoteException, NotBoundException, InterruptedException {
		Tracer.showWarnings(false);
		//Show traceables
		Tracer.showInfo(false);
		Scanner input = new Scanner(System.in);
		Object lock = new Object();
		new BasicBeauRMIServer("server");
		Client toTest = new RMIClient("ClientOne");
		Client toTestTwo = new RMIClient("ClientTwo");
		toTest.registerWithServer("server");
		toTestTwo.registerWithServer("server");
		
		System.out.println("Ready to do local, press enter to proceed");
		input.nextLine();
		int backAndForth = 0;
	
		toTest.sendCommandController("move 120 -75");
		
		synchronized (lock) {
			lock.wait(2000);
		}
		
		while (backAndForth < 6) {
			for (int i = 0; i < 200; i++) {
				toTest.sendCommandController("move 1 0");
				
			}
	
			for (int i = 0; i < 200; i++) {
				toTest.sendCommandController("move -1 0");
			}
			
			backAndForth++;
		}
		
		toTestTwo.sendCommandController("move 120 -75");
		
		System.out.println("Ready to do non-atomic, press enter to proceed");
		input.nextLine();
		backAndForth = 0;
		toTest.sendMode("non-atomic");
		
		synchronized (lock) {
			lock.wait(2000);
		}
		
		while (backAndForth < 6) {
			toTest.stressTestNonAtomic("take 1");
			for (int i = 0; i < 200; i++) {
				toTest.stressTestNonAtomic("move 1 0");
				
			}
	
			for (int i = 0; i < 200; i++) {
				toTest.stressTestNonAtomic("move -1 0");
			}
			
			backAndForth++;
		}
		
		System.out.println("Ready to do atomic, press enter to proceed");
		input.nextLine();
		backAndForth = 0;
		toTest.sendMode("atomic");
		
		synchronized (lock) {
			lock.wait(2000);
		}
		
		while (backAndForth < 6) {
			toTest.sendCommandController("give 1");
			for (int i = 0; i < 200; i++) {
				toTest.sendCommandController("move 1 0");
				
			}
	
			for (int i = 0; i < 200; i++) {
				toTest.sendCommandController("move -1 0");
			}
			
			backAndForth++;
		}
	}
}
