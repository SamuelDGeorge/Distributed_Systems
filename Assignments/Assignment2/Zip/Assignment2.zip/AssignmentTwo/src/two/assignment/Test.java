package two.assignment;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import two.clients.Client;
import two.clients.RMIClient;
import two.server.BasicBeauRMIServer;
import two.ui.ABeauController;
import util.trace.Tracer;


public class Test {
	
	public static void main(String[] args) throws RemoteException, NotBoundException {
		Tracer.showWarnings(false);
		//Show traceables
		Tracer.showInfo(false);
		new BasicBeauRMIServer("server");
		new RMIClient("ClientOne").registerWithServer("server");
		new RMIClient("ClientTwo").registerWithServer("server");
		//new RMIClient("ClientThree").registerWithServer("server");
		
		
	}
}
