package two.clients;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import StringProcessors.HalloweenCommandProcessor;
import main.BeauAndersonFinalProject;
import two.server.BeauRMIServer;
import two.ui.ABeauController;
import two.ui.BeauController;
import two.ui.EventHandler;

public class RMIClient implements Client,PropertyChangeListener {
	private static int SIMULATION_COMMAND_Y_OFFSET = 0;
	private static int SIMULATION_WIDTH = 400;
	private static int SIMULATION_HEIGHT = 765;
	private HalloweenCommandProcessor simulation;
	private boolean local;
	private boolean nonAtomic;
	private boolean atomic;
	private String name;
	private BeauRMIServer proxyOfServer;
	private BeauController controller;
	private BlockingQueue<PropertyChangeEvent> eventQueue; 
	
	public RMIClient(String clientName) throws RemoteException, NotBoundException {
		this.controller = new ABeauController(this);
		this.simulation = BeauAndersonFinalProject.createSimulation(
				"SIMULATION1_PREFIX", 0, SIMULATION_COMMAND_Y_OFFSET, SIMULATION_WIDTH, SIMULATION_HEIGHT, 0, 0);
		this.local = true;
		this.nonAtomic = false;
		this.atomic = false;
		this.name = clientName;
		this.eventQueue = new LinkedBlockingQueue<PropertyChangeEvent>();
		new Thread(new EventHandler(this,this.simulation,this.eventQueue)).start();
		this.simulation.addPropertyChangeListener(this);
	}
	
	

	
	public void setModeLocal() throws RemoteException {
		this.local = true;
		this.nonAtomic = false;
		this.atomic = false;
		this.simulation.setConnectedToSimulation(true);
		this.controller.setSelected("local");
	}

	
	public void setModeNonAtomic() throws RemoteException {
		this.local = false;
		this.nonAtomic = true;
		this.atomic = false;
		this.simulation.setConnectedToSimulation(true);
		this.controller.setSelected("non-atomic");
		
	}

	
	public void setModeAtomic() throws RemoteException {
		this.local = false;
		this.nonAtomic = false;
		this.atomic = true;
		this.simulation.setConnectedToSimulation(false);
		this.controller.setSelected("atomic");
		
		
	}

	
	public void processCommand(String source,String toExecute) throws RemoteException{
		if (this.local) {
			//ignore
		} else if (this.nonAtomic) {
			if(this.name.equals(source)) {
				//do nothing
			} else {
				this.simulation.processCommand(toExecute);
			}
		} else {
			this.simulation.processCommand(toExecute);
		}
		this.controller.setText(toExecute);
	}


	
	public void sendCommand(String toExecute) throws RemoteException {
		if (this.local) {
			this.simulation.processCommand(toExecute);
		} else if (this.nonAtomic) {
			this.proxyOfServer.EchoString(this.name, toExecute);
		} else {
			this.proxyOfServer.EchoString(this.name, toExecute);
		}	
	}
	
	public void sendCommandController(String toExecute) throws RemoteException{
		if (this.local) {
			this.simulation.processCommand(toExecute);
		} else if (this.nonAtomic) {
			this.simulation.processCommand(toExecute);
			this.proxyOfServer.EchoString(this.name, toExecute);
		} else {
			this.proxyOfServer.EchoString(this.name, toExecute);
		}	
	}




	
	public String getName() {
		return this.name;
	}




	
	public void registerWithServer(String serverName) throws RemoteException {
		try {
			Registry rmiRegistry = LocateRegistry.getRegistry(REGISTRY_HOST_NAME, REGISTRY_PORT_NAME);
			UnicastRemoteObject.exportObject(this, 0);
			rmiRegistry.bind(this.name, this);
			this.proxyOfServer = (BeauRMIServer) rmiRegistry.lookup(serverName);
			this.proxyOfServer.join(this.name);
		} catch (Exception e) {
			System.out.println("Unable to Find Server");
			e.printStackTrace();
		}
		
	}


	public void sendMode(String mode) throws RemoteException {
		if (this.proxyOfServer == null) {
			setModeLocal();
		} else if (mode.equals("local")) {
			setModeLocal();
			this.proxyOfServer.setClientModes(mode);
		} else if (mode.equals("non-atomic")) {
			setModeNonAtomic();
			this.proxyOfServer.setClientModes(mode);
		} else {
			this.proxyOfServer.setClientModes(mode);
		}
		
	}

	public void propertyChange(PropertyChangeEvent evt) {
		try {
			this.eventQueue.put(evt);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}


	public boolean isLocal() {return this.local;}

	public boolean isNonAtomic() {return this.nonAtomic;}

	public boolean isAtomic() {return this.atomic;}

	public void stressTestNonAtomic(String command) throws RemoteException {
		if (this.nonAtomic) {
			this.simulation.setInputString(command);
		}
		
	}



}
