package two.clients;

public interface ClientStarter {
	static int REGISTRY_PORT_NAME = 4999;
	static String CLIENT_NAME = "beau";
	static String REGISTRY_HOST_NAME = "localhost";
	public void startClient(String name);
}
