package two.clients;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import two.ui.ABeauController;

public class AClientStarter implements ClientStarter {
	public void startClient(String clientName) {
		try {
			Registry rmiRegistry = LocateRegistry.getRegistry(REGISTRY_HOST_NAME, REGISTRY_PORT_NAME);
			Client beauClient = (Client) rmiRegistry.lookup(clientName);
			new ABeauController(beauClient);
		} catch (RemoteException | NotBoundException e) {
			System.out.println("Failed to start Client.");
		}
		
	}
}
