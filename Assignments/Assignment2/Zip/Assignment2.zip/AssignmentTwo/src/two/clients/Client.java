package two.clients;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Client extends Remote{
	static String REGISTRY_HOST_NAME = "localhost";
	static int REGISTRY_PORT_NAME = 4999;
	public void processCommand(String Source,String toExecute) throws RemoteException;
	public void sendCommand(String toExecute) throws RemoteException;
	public void sendCommandController(String toExecute) throws RemoteException;
	public void setModeLocal() throws RemoteException;
	public void setModeNonAtomic() throws RemoteException;
	public void setModeAtomic() throws RemoteException;
	public String getName() throws RemoteException;
	public void registerWithServer(String serverName) throws RemoteException;
	public void sendMode(String mode) throws RemoteException;
	public boolean isLocal() throws RemoteException;
	public boolean isNonAtomic() throws RemoteException;
	public boolean isAtomic() throws RemoteException;
	public void stressTestNonAtomic(String command) throws RemoteException;
}
