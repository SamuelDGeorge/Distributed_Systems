package six.runners;



public class ASessionServerLauncher  {
	
	public static void main (String args[]) {	
		port.sessionserver.ASessionServerLauncher.main(args);
	}
	


	
	
	
}
