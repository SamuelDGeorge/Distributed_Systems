package six.paxos.scenarios;



public class ASessionServerLauncher  {
	
	public static void main (String args[]) {	
		port.sessionserver.ASessionServerLauncher.main(args);
	}
	


	
	
	
}
