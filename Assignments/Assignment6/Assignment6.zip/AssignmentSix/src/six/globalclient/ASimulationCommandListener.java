package six.globalclient;

import StringProcessors.HalloweenCommandProcessor;
import consensus.ConsensusListener;
import consensus.ProposalState;
import three.clients.GlobalClient;

public class ASimulationCommandListener implements ConsensusListener<String> {
	private HalloweenCommandProcessor simulation;
	private PaxosClient client;
	
	ASimulationCommandListener(HalloweenCommandProcessor sim, PaxosClient client) {
		this.simulation = sim;
		this.client = client;
	}
	
	@Override
	public void newLocalProposalState(float aProposalNumber, String aProposal, ProposalState aProposalState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newRemoteProposalState(float aProposalNumber, String aProposal, ProposalState aProposalState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newProposalState(float aProposalNumber, String aProposal, ProposalState aProposalState) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newConsensusState(String aState) {
		//System.out.println("Command Recieved: " + aState);
		String[] parsed = aState.split(":");
		if("Mode".equals(parsed[0])) {
			int mode = Integer.parseInt(parsed[1]);
			if (mode == 1) {
				this.client.simulateNonAtomicAsynchronous();
				System.out.println("Paxos Mode Changed to: " + "NonAtomicAsynchronous");
			} else if (mode == 2) {
				this.client.simulateNonAtomicSynchronous();
				System.out.println("Paxos Mode Changed to: " + "NonAtomicSynchronous");
			} else if (mode == 3) {
				this.client.simulateCentralizedAsynchronous();
				System.out.println("Paxos Mode Changed to: " + "CentralizedAsynchronous");
			} else if (mode ==4) {
				this.client.simulateCentralizedSynchronous();
				System.out.println("Paxos Mode Changed to: " + "Centralizedsynchronous");
			} else if (mode == 5) {
				this.client.simulateSequentialPaxos();
				System.out.println("Paxos Mode Changed to: " + "SequentialPaxos");
			} else {
				System.out.println("Invalid State Proposed: " + mode);
			}
		} else {
			this.simulation.processCommand(aState);
		}
		
		
		
	}

}
