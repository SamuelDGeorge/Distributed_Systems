package six.globalclient;

public interface SimulationMember {
	static int SESSION_MANAGER_PORT_NAME = 4999;
	static String EXAMPLE_SESSION = "Example Session";
	static String SESSION_MANAGER_HOST = "localhost";
	static String COMMAND_CONSENSUS_MECHANISM_NAME = "Command";
	static String MODE_CONSENSUS_MECHANISM_NAME = "Mode";
}
