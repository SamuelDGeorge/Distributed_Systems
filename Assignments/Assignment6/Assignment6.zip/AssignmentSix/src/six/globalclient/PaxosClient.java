package six.globalclient;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;

import StringProcessors.HalloweenCommandProcessor;
import consensus.ConcurrencyKind;
import consensus.ConsensusMechanism;
import consensus.ConsensusMechanismFactory;
import consensus.ProposalState;
import consensus.ReplicationSynchrony;
import consensus.asynchronous.sequential.AnAsynchronousConsensusMechanismFactory;
import consensus.paxos.sequential.ASequentialPaxosConsensusMechanismFactory;
import consensus.sessionport.AConsensusMemberLauncher;
import examples.gipc.consensus.ExampleMember;
import examples.gipc.consensus.paxos.APaxosMemberLauncher;
import three.clients.GlobalClient;
import util.misc.ThreadSupport;

public class PaxosClient extends AConsensusMemberLauncher implements SimulationMember {
	public static long INIT_TIME = 6000;
	public static long RE_PROPOSE_TIME = 10000;
	protected  ConsensusMechanism<String> commandMechanism;
	protected HalloweenCommandProcessor simulation;
	protected boolean overrideRetry;
	
	public PaxosClient(String aLocalName, int aPortNumber, HalloweenCommandProcessor sim) {
		super(aLocalName, aPortNumber);
		this.simulation = sim;
		addListenersAndVetoersToConsensusMechanisms();
		this.simulateSequentialPaxos();
	}
	
	@Override
	protected void initConsensusMechanisms(short anId) {
		setFactories();
		createConsensusMechanisms(anId);
		customizeConsensusMechanisms();
	}

	public void proposeCommand(String aValue) {
			//System.out.println("Making proposal of:" + aValue);
			float aMeaningOfLifeProposal = commandMechanism.propose(aValue);
			ProposalState aState = commandMechanism.waitForConsensus(
					aMeaningOfLifeProposal);
		
	}
	
	@Override
	protected short numMembersToWaitFor() {
		return 3;
	}
	
	protected ConsensusMechanismFactory<Integer> modeConsensusMechanismFactory() {
		return new ASequentialPaxosConsensusMechanismFactory();
	}
	
	protected  ConsensusMechanismFactory<String> commandConsensusMechanismFactory() {
		return new ASequentialPaxosConsensusMechanismFactory();
	}
	
	protected void createCommandConsensusMechanism() {
		commandMechanism = commandConsensusMechanismFactory().createConsensusMechanism(
				SESSION_MANAGER_HOST,
				EXAMPLE_SESSION,
				memberId, portNumber, 
				MODE_CONSENSUS_MECHANISM_NAME, 
				sessionChoice, 
				numMembersToWaitFor());
	}

	@Override
	protected void createConsensusMechanisms(short anId) {
		createCommandConsensusMechanism();
		
	}

	@Override
	protected void addListenersAndVetoersToConsensusMechanisms() {
		this.commandMechanism.addConsensusListener(new ASimulationCommandListener(this.simulation,this));
	}
	
	protected void simulateNonAtomicAsynchronous() {
		commandMechanism.setAcceptSynchrony(ReplicationSynchrony.ASYNCHRONOUS);
		commandMechanism.setConcurrencyKind(ConcurrencyKind.NON_ATOMIC);
		commandMechanism.setSequentialAccess(false);
	}
	protected void simulateNonAtomicSynchronous() {
		commandMechanism.setAcceptSynchrony(ReplicationSynchrony.ALL_SYNCHRONOUS);
		commandMechanism.setConcurrencyKind(ConcurrencyKind.NON_ATOMIC);
		commandMechanism.setSequentialAccess(false);
	}
	protected void simulateCentralized() {
		commandMechanism.setCentralized(true);
	}
	protected void simulateCentralizedSynchronous() {
		simulateNonAtomicSynchronous();
		simulateCentralized();
	}
	protected void simulateCentralizedAsynchronous() {
		simulateNonAtomicAsynchronous();
		simulateCentralized();
	}
	protected void simulateBasicPaxos() {
		overrideRetry = true;
		commandMechanism.setCentralized(false);
		commandMechanism.setConcurrencyKind(ConcurrencyKind.SERIALIZABLE);
		commandMechanism
				.setPrepareSynchrony(ReplicationSynchrony.MAJORITY_SYNCHRONOUS);
		commandMechanism
				.setAcceptSynchrony(ReplicationSynchrony.MAJORITY_SYNCHRONOUS);
	}
	protected void simulateSequentialPaxos() {
		simulateBasicPaxos();
		commandMechanism.setSequentialAccess(true);
		overrideRetry = false;
	}	
	
	protected Long reProposeTime() {
		return overrideRetry?null:RE_PROPOSE_TIME;
	}
	

	@Override
	protected void customizeConsensusMechanisms() {
		simulateSequentialPaxos();
	}
	


}
