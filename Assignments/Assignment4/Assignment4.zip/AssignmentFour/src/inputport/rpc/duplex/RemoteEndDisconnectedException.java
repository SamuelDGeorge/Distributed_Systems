package inputport.rpc.duplex;

public class RemoteEndDisconnectedException extends GIPCRemoteException {

	public RemoteEndDisconnectedException(String aMessage) {
		super(aMessage);
		// TODO Auto-generated constructor stub
	}
	public RemoteEndDisconnectedException() {
		
	}

}
