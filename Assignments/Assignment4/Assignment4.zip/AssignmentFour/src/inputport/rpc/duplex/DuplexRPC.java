package inputport.rpc.duplex;

import inputport.rpc.simplex.SimplexRPC;

public interface DuplexRPC extends SimplexRPC, ReplyRPC {

}
