package inputport.rpc.duplex;

public interface LocalRemoteReferenceTranslatorFactory {
	LocalRemoteReferenceTranslator createLocalRemoteReferenceTranslator(DuplexRPCInputPort aDuplexRPCPort);

}
