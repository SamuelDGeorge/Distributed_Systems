package inputport.rpc.duplex;

public class ARemoteEndDisconnected implements RPCReturnValue {

	@Override
	public Object getReturnValue() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isException() {
		return true;
	}

}
