package inputport.rpc.duplex;

import inputport.rpc.simplex.SimplexSentCallCompleter;

public interface DuplexSentCallCompleter extends SimplexSentCallCompleter, MaybeProcessReturnValue {

}
