package inputport.rpc.duplex;

public interface MaybeProcessReturnValue {
	boolean maybeProcessReturnValue(String aSource, Object aMessage);


}
