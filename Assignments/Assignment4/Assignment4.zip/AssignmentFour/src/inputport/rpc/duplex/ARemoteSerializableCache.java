package inputport.rpc.duplex;

public class ARemoteSerializableCache implements RemoteSerializableCache{
	
	@Override
	public Object get(RemoteSerializable remoteSerializable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object put(RemoteSerializable remoteSerializable, Object proxy) {
		// TODO Auto-generated method stub
		return null;
	}

}
