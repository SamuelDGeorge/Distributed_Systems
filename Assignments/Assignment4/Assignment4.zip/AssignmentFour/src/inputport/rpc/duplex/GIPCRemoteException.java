package inputport.rpc.duplex;

public class GIPCRemoteException extends RuntimeException {
	public GIPCRemoteException(String aMessage) {
		super(aMessage);
	}
	public GIPCRemoteException() {
		
	}
}
