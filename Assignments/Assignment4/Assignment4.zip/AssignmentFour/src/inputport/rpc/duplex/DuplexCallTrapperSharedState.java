package inputport.rpc.duplex;

public class DuplexCallTrapperSharedState {
	public LocalRemoteReferenceTranslator localRemoteReferenceTranslator;
	public DuplexSentCallCompleter duplexSentCallCompleter;	

}
