package examples.gipc.counter.customization;

import inputport.datacomm.duplex.object.DuplexObjectInputPortSelector;
import inputport.datacomm.duplex.object.explicitreceive.ReceiveReturnMessage;
import inputport.rpc.duplex.DuplexReceivedCallInvokerSelector;
import inputport.rpc.duplex.DuplexSentCallCompleterSelector;
import inputport.rpc.duplex.SynchronousDuplexReceivedCallInvokerSelector;
import port.trace.buffer.BufferTraceUtility;
import port.trace.objects.ObjectTraceUtility;
import port.trace.rpc.RPCTraceUtility;
import serialization.SerializerSelector;

import java.util.Scanner;

import examples.gipc.counter.layers.AMultiLayerCounterClient;

public class MyACustomCounterClient extends AMultiLayerCounterClient{
	public static void setFactories() {
		DuplexReceivedCallInvokerSelector.setReceivedCallInvokerFactory(
				new ACustomDuplexReceivedCallInvokerFactory());
//		DuplexReceivedCallInvokerSelector.setReceivedCallInvokerFactory(
//				new AnAsynchronousCustomDuplexReceivedCallInvokerFactory());
		DuplexSentCallCompleterSelector.setDuplexSentCallCompleterFactory(
				new ACustomSentCallCompleterFactory());
		DuplexObjectInputPortSelector.setDuplexInputPortFactory(
				new ACustomDuplexObjectInputPortFactory());
		SerializerSelector.setSerializerFactory(new ACustomSerializerFactory());	
	}
	public static void main (String[] args) {
		BufferTraceUtility.setTracing();
		RPCTraceUtility.setTracing();
		ObjectTraceUtility.setTracing();
		
		setFactories();
		init("Client 1");
		setPort();
		//sendByteBuffers();
		//sendObjects();
		//doOperations();	
		Scanner input = new Scanner(System.in);
		String current = null;
		while(true) {
			current = input.nextLine();
			if("increment".equals(current)) {
				doIncrement();
			} else if ("print".equals(current)) {
				doPrint();
			} else if ("receive".equals(current)) {
				gipcRegistry.getRPCClientPort().receive();
			} else if ("speedtestinc".equals(current)) {
				long start = System.nanoTime();
				for(int i = 0; i < 500; i++) {
					doIncrement();
				}
				long end = System.nanoTime();
				System.out.println("Test took: " + (end - start)/1000000 + "ms");
			} else if ("speedtestprint".equals(current)) {
				long start = System.nanoTime();
				for(int i = 0; i < 500; i++) {
					doPrint();
				}
				long end = System.nanoTime();
				System.out.println("Test took: " + (end - start)/1000000 + "ms");
			} else if ("exit".equals(current)) {
				System.out.println("Goodbye");
				System.exit(0);
			} else {
				System.out.println("Invalid Command. Try again!");
			}
		}
		
	}
	

}
