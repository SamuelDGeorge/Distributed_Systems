package examples.gipc.counter.customization;

import util.trace.Tracer;

import java.util.ArrayList;
import java.util.List;

import four.utilities.ABlockingBufferFactory;
import four.utilities.AMessage;
import four.utilities.Message;
import inputport.datacomm.AReceiveRegistrarAndNotifier;
import inputport.datacomm.ReceiveListener;
import port.trace.objects.ReceivedMessageQueued;

public class ACustomReceiveNotifier extends AReceiveRegistrarAndNotifier{
	List<String> sources = new ArrayList<String>();
	
	@Override
	public void notifyPortReceive (String aSource, Object aMessage) {	
		//System.out.println (aSource + "->" + aMessage);
		try {
				ABlockingBufferFactory.getClientBuffer().put(new AMessage(aSource,aMessage));
				ReceivedMessageQueued.newCase(this, ABlockingBufferFactory.getClientBuffer(), "Put in General Client Queue");
			
			if(!sources.contains(aSource)) {
			
				sources.add(aSource);
				//ABlockingBufferFactory.getGeneralServerBuffer().put(new AMessage(aSource,aMessage));
				ABlockingBufferFactory.getServerPortBuffer(aSource).put(new AMessage(aSource,aMessage));
				//ReceivedMessageQueued.newCase(this, ABlockingBufferFactory.getGeneralServerBuffer(), "Put in General Server Queue");
				ReceivedMessageQueued.newCase(this, ABlockingBufferFactory.getServerPortBuffer(aSource), "Put in " + aSource +  " Server Queue");
			
			} else {
				
				ABlockingBufferFactory.getServerPortBuffer(aSource).put(new AMessage(aSource,aMessage));
				ReceivedMessageQueued.newCase(this, ABlockingBufferFactory.getServerPortBuffer(aSource), "Put in " + aSource +  " Server Queue");
			}
			
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		};
		
		super.notifyPortReceive(aSource, aMessage);
	}
}
