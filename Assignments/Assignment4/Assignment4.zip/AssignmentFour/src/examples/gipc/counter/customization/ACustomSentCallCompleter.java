package examples.gipc.counter.customization;

import inputport.datacomm.duplex.object.explicitreceive.ReceiveReturnMessage;
import four.utilities.ABlockingBufferFactory;
import four.utilities.AMessage;
import inputport.datacomm.duplex.object.explicitreceive.ExplicitSourceReceive;
import inputport.rpc.ASerializableCall;
import inputport.rpc.duplex.ADuplexSentCallCompleter;
import inputport.rpc.duplex.DuplexRPCInputPort;
import inputport.rpc.duplex.LocalRemoteReferenceTranslator;
import inputport.rpc.duplex.RPCReturnValue;
import port.trace.objects.ReceivedMessageQueued;

public class ACustomSentCallCompleter extends ADuplexSentCallCompleter	{
	private ACustomDuplexObjectClientInputPort waitPortClient;
	private ACustomDuplexObjectServerInputPort waitPortServer;
	
	public ACustomSentCallCompleter(DuplexRPCInputPort aPort, LocalRemoteReferenceTranslator aRemoteHandler) {
		super(aPort, aRemoteHandler);	
		if(aPort.getDuplexInputPort() instanceof ACustomDuplexObjectClientInputPort) {
			waitPortClient = (ACustomDuplexObjectClientInputPort)aPort.getDuplexInputPort();
		} else if (aPort.getDuplexInputPort() instanceof ACustomDuplexObjectServerInputPort) {
			waitPortServer = (ACustomDuplexObjectServerInputPort)aPort.getDuplexInputPort();
		} else {}
	}	
	
	@Override
	protected void returnValueReceived(String aRemoteEndPoint, Object message) {
		//do nothing
		//This is handled in the ACustomReceiveNotifier
	}
	@Override
	public Object waitForReturnValue(String aRemoteEndPoint) {		
		Object retVal = null;
		ReceiveReturnMessage<Object> untranslated = null;
		if(!(waitPortClient == null)) {
			untranslated = waitPortClient.receive(aRemoteEndPoint);
			try {
				retVal = ((RPCReturnValue) untranslated.getMessage()).getReturnValue();
			} catch (ClassCastException w)  {
				//retVal = ((ASerializableCall) untranslated.getMessage()).getSerializableMethod();
			}
			
		} else if (!(waitPortServer == null)) {
			untranslated = waitPortServer.receive(aRemoteEndPoint);
			try {
				retVal = ((RPCReturnValue) untranslated.getMessage()).getReturnValue();
			} catch (ClassCastException w)  {
				//retVal = ((ASerializableCall) untranslated.getMessage()).getSerializableMethod();
			}
		} else {
			retVal = super.waitForReturnValue(aRemoteEndPoint);
		}
		//System.out.println (aRemoteEndPoint +  "-->" + retVal);
		
		return retVal;
	}
	
}
