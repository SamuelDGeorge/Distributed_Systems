package examples.gipc.counter.customization;

import java.nio.ByteBuffer;

import four.utilities.ABlockingBufferFactory;
import four.utilities.Message;
import inputport.datacomm.AReceiveRegistrarAndNotifier;
import inputport.datacomm.ReceiveRegistrarAndNotifier;
import inputport.datacomm.duplex.DuplexServerInputPort;
import inputport.datacomm.duplex.object.ADuplexObjectServerInputPort;
import inputport.datacomm.duplex.object.explicitreceive.AReceiveReturnMessage;
import inputport.datacomm.duplex.object.explicitreceive.ReceiveReturnMessage;
import port.trace.objects.ReceivedMessageDequeued;

public class ACustomDuplexObjectServerInputPort extends ADuplexObjectServerInputPort{

	public ACustomDuplexObjectServerInputPort(
			DuplexServerInputPort<ByteBuffer> aBBDuplexServerInputPort) {
		super(aBBDuplexServerInputPort);
	}

	protected ReceiveRegistrarAndNotifier<Object> createReceiveRegistrarAndNotifier() {
		return new ACustomReceiveNotifier();
	}
	
	@Override
	public ReceiveReturnMessage<Object> receive() {
		AReceiveReturnMessage<Object> toReturnObject = null;
		if(this.getSender() == null) {
			try {
				Message toReturn = ABlockingBufferFactory.getGeneralServerBuffer().take();
				ReceivedMessageDequeued.newCase(this, ABlockingBufferFactory.getGeneralServerBuffer(), "Message Dequeued From: " + "General Server Buffer");
				toReturnObject = new AReceiveReturnMessage(toReturn.getSource(),toReturn.getMessage());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
			
		} else {
				return receive(this.getSender());
			
		}
		return toReturnObject;

	}
	
	@Override
	public ReceiveReturnMessage<Object> receive(String aSource) {
		AReceiveReturnMessage<Object> toReturnObject = null;
		if ("*".equals(aSource)) {
			try {
				Message toReturn = ABlockingBufferFactory.getGeneralServerBuffer().take();
				ReceivedMessageDequeued.newCase(this, ABlockingBufferFactory.getGeneralServerBuffer(), "Message Dequeued From: " + "General Server Buffer");
				toReturnObject = new AReceiveReturnMessage(toReturn.getSource(),toReturn.getMessage());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		} else {
			try {
				Message toReturn = ABlockingBufferFactory.getServerPortBuffer(aSource).take();
				ReceivedMessageDequeued.newCase(this, ABlockingBufferFactory.getGeneralServerBuffer(), "Message Dequeued From: " + aSource + " Buffer");
				toReturnObject = new AReceiveReturnMessage(toReturn.getSource(),toReturn.getMessage());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
		return toReturnObject;

	}

}
