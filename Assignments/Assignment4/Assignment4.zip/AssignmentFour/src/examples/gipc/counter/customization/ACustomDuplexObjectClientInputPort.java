package examples.gipc.counter.customization;

import java.nio.ByteBuffer;

import four.utilities.ABlockingBufferFactory;
import four.utilities.Message;
import inputport.datacomm.ReceiveRegistrarAndNotifier;
import inputport.datacomm.duplex.DuplexClientInputPort;
import inputport.datacomm.duplex.object.ADuplexObjectClientInputPort;
import inputport.datacomm.duplex.object.DuplexObjectInputPortSelector;
import inputport.datacomm.duplex.object.explicitreceive.AReceiveReturnMessage;
import inputport.datacomm.duplex.object.explicitreceive.ReceiveReturnMessage;
import port.trace.objects.ReceivedMessageDequeued;

public class ACustomDuplexObjectClientInputPort extends ADuplexObjectClientInputPort {

	public ACustomDuplexObjectClientInputPort(
			DuplexClientInputPort<ByteBuffer> aBBClientInputPort) {
		super(aBBClientInputPort);
	}
	
	protected ReceiveRegistrarAndNotifier<Object> createReceiveRegistrarAndNotifier() {
		return new ACustomReceiveNotifier();
	}
	
	@Override
	public void send(String aDestination, Object aMessage) {
		//System.out.println (aDestination + "<-" + aMessage);
		super.send(aDestination, aMessage);	
	}
		
	
	public ReceiveReturnMessage<Object> receive(String aSource) {
		Message received = null;
		try {
			received = ABlockingBufferFactory.getClientBuffer().take();
			ReceivedMessageDequeued.newCase(this, ABlockingBufferFactory.getClientBuffer(), "Message Dequeued From: " + aSource + " Buffer");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return new AReceiveReturnMessage(received.getSource(),received.getMessage());

	}
//	@Override
//	public ReceiveReturnMessage<Object> receive(String aSource) {
//		System.err.println("Receive started");
//		ReceiveReturnMessage retVal = super.receive(aSource);
//		System.out.println (aSource + "<-" + retVal);
//		return retVal;
//	}
}
