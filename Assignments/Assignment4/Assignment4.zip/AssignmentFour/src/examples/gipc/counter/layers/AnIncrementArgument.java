package examples.gipc.counter.layers;

public class AnIncrementArgument {
	protected int addition;
	public int getAddition() {
		return addition;
	}
	public void setAddition(int anAddition) {		
		addition = anAddition;
	}

}
