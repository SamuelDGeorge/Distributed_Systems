package examples.gipc.counter.customization;

import inputport.datacomm.duplex.object.DuplexObjectInputPortSelector;
import inputport.datacomm.duplex.object.explicitreceive.ReceiveReturnMessage;
import inputport.rpc.duplex.DuplexReceivedCallInvokerSelector;
import inputport.rpc.duplex.DuplexSentCallCompleterSelector;
import port.trace.buffer.BufferTraceUtility;
import port.trace.objects.ObjectTraceUtility;
import port.trace.rpc.RPCTraceUtility;
import util.trace.Tracer;
import examples.gipc.counter.layers.AMultiLayerCounterClient;
import examples.gipc.counter.layers.AMultiLayerCounterServer;

public class MyACustomCounterServer extends AMultiLayerCounterServer{
	public static void setFactories() {
		MyACustomCounterClient.setFactories();

	}
	public static void main (String[] args) {		
//		BufferTraceUtility.setTracing();
//		RPCTraceUtility.setTracing();
//		ObjectTraceUtility.setTracing();
		
		setFactories();
		init();
		setPort();
		addListeners();
	}
	

}
