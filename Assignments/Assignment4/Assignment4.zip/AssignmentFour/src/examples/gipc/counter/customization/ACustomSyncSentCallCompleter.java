package examples.gipc.counter.customization;

import inputport.rpc.duplex.DuplexRPCInputPort;
import inputport.rpc.duplex.LocalRemoteReferenceTranslator;
import port.trace.rpc.ReceivedObjectTransformed;
import port.trace.rpc.RemoteCallReceivedReturnValue;
import port.trace.rpc.RemoteCallWaitingForReturnValue;

public class ACustomSyncSentCallCompleter extends ACustomSentCallCompleter {

	public ACustomSyncSentCallCompleter(DuplexRPCInputPort aPort, LocalRemoteReferenceTranslator aRemoteHandler) {
		super(aPort, aRemoteHandler);
	}

	
	@Override
	protected Object getReturnValueOfRemoteFunctionCall(String aRemoteEndPoint, Object aMessage) {
		//System.out.println ("getReturnValueOfRemoteFunctionCall called");
		Object retVal = super.getReturnValueOfRemoteFunctionCall(aRemoteEndPoint, aMessage);
		//System.out.println ("Returning:" + retVal);
		return retVal;
	}
	
	@Override
	protected Object getReturnValueOfRemoteProcedureCall(String aRemoteEndPoint, Object aMessage) {
		//System.out.println ("getReturnValueOfRemoteProcedureCall called");
		RemoteCallWaitingForReturnValue.newCase(this);
		Object possiblyRemoteRetVal = waitForReturnValue(aRemoteEndPoint);
		Object returnValue = localRemoteReferenceTranslator.transformReceivedReference(possiblyRemoteRetVal);
		//System.out.println("Waited for Receive. Remote procedure call returned: " + returnValue);
		return returnValue;
	}
}
