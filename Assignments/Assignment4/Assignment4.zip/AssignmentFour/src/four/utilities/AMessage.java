package four.utilities;

public class AMessage implements Message {
	private String source;
	private Object message;
	
	public AMessage(String source, Object message) {
		this.source = source;
		this.message = message;
	}
	
	public String getSource(){return this.source;}
	public Object getMessage() {return this.message;}
}
