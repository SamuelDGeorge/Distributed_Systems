package four.utilities;

public interface Message {
	public String getSource();
	public Object getMessage();
}
