package four.utilities;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import inputport.datacomm.ReceiveRegistrarAndNotifier;
import port.trace.objects.ReceivedMessageQueueCreated;

public class ABlockingBufferFactory  {
	private static Map<String,BlockingQueue<Message>> buffers = new HashMap<String,BlockingQueue<Message>>();
	private	static BlockingQueue<Message> clientBuffer;
	private static BlockingQueue<Message> generalServerBuffer;
	
	
	public static BlockingQueue<Message> getClientBuffer() {
		if(clientBuffer == null) {
			clientBuffer = new LinkedBlockingQueue<Message>();
			ReceivedMessageQueueCreated.newCase(new ABlockingBufferFactory(), clientBuffer, "client use.");
			return clientBuffer;
		}
		return clientBuffer;
	}
	
	public static BlockingQueue<Message> getGeneralServerBuffer() {
		if(generalServerBuffer == null) {
			generalServerBuffer = new LinkedBlockingQueue<Message>();
			ReceivedMessageQueueCreated.newCase(new ABlockingBufferFactory(), generalServerBuffer, "general server use.");
			return generalServerBuffer;
		}
		return generalServerBuffer;
	}

	public static BlockingQueue<Message> getServerPortBuffer(String portRecievedOn) {
		if (buffers.get(portRecievedOn) == null) {
			buffers.put(portRecievedOn, new LinkedBlockingQueue<Message>());
			ReceivedMessageQueueCreated.newCase(new ABlockingBufferFactory(), buffers.get(portRecievedOn), "use by client: " + portRecievedOn);
			return buffers.get(portRecievedOn);
		}
		return buffers.get(portRecievedOn);
	}

}
