package speedtest;

import java.io.IOException;
import java.net.UnknownHostException;
import java.rmi.NotBoundException;
import java.util.Scanner;

import examples.gipc.counter.customization.ACustomDuplexObjectInputPortFactory;
import examples.gipc.counter.customization.ACustomDuplexReceivedCallInvokerFactory;
import examples.gipc.counter.customization.ACustomSentCallCompleterFactory;
import examples.gipc.counter.customization.ACustomSerializerFactory;
import examples.gipc.counter.customization.AnAsynchronousCustomDuplexReceivedCallInvokerFactory;
import inputport.datacomm.duplex.object.DuplexObjectInputPortSelector;
import inputport.datacomm.simplex.buffer.nio.AScatterGatherSelectionManager;
import inputport.rpc.duplex.DuplexReceivedCallInvokerSelector;
import inputport.rpc.duplex.DuplexSentCallCompleterSelector;
import port.trace.buffer.BufferTraceUtility;
import port.trace.nio.NIOTraceUtility;
import port.trace.objects.ObjectTraceUtility;
import port.trace.rpc.RPCTraceUtility;
import serialization.SerializerSelector;
import three.server.AGlobalServer;
import three.server.GlobalServer;
import util.trace.Tracer;


public class ServerExplicitGIPC {
	
	public static void main(String[] args) throws NotBoundException, UnknownHostException, IOException {
		//DuplexReceivedCallInvokerSelector.setReceivedCallInvokerFactory(
		//		new ACustomDuplexReceivedCallInvokerFactory());
		DuplexReceivedCallInvokerSelector.setReceivedCallInvokerFactory(
				new AnAsynchronousCustomDuplexReceivedCallInvokerFactory());
		DuplexSentCallCompleterSelector.setDuplexSentCallCompleterFactory(
		new ACustomSentCallCompleterFactory());
		DuplexObjectInputPortSelector.setDuplexInputPortFactory(
		new ACustomDuplexObjectInputPortFactory());
		SerializerSelector.setSerializerFactory(new ACustomSerializerFactory());
		Tracer.showWarnings(false);
		//Tracer.showInfo(true);
		//NIOTraceUtility.setTracing();
		//BufferTraceUtility.setTracing();
		//RPCTraceUtility.setTracing();
		//ObjectTraceUtility.setTracing();
		AScatterGatherSelectionManager.setMaxOutstandingWrites(750);
		GlobalServer server  = new AGlobalServer();
		server.setSynchronizedResponse(true);
		
		
		serverController(server);
	}

	private static void serverController(GlobalServer server) {
		Scanner input = new Scanner(System.in);
		String current;
		while (true) {
			System.out.println("Please enter a valid command:");
			current = input.nextLine();
			if("race".equals(current)) {
				System.out.println("Would you like race condition checking On(Y) or Off(N)");
				current = input.nextLine();
				if("Y".equals(current)) {
					server.setSynchronizedResponse(true);
				} else {
					server.setSynchronizedResponse(false);
				}
			} else if ("exit".equals(current)) {
				System.out.println("Server shutting down!");
				System.exit(0);
			} else {
				System.out.println("Not a valid command");
			}
		}
		
	}
	
	

}
