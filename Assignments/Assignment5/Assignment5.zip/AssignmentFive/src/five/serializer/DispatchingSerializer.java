package five.serializer;

import java.io.NotSerializableException;
import java.util.List;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.DISPATCHING_SERIALIZER})
public interface DispatchingSerializer {
	public void objectToBuffer(Object anOutputBuffer,Object anObject, List<Object> visitedObjects) throws NotSerializableException;
	public Object objectFromBuffer(Object anInputBuffer, List<Object> retrievedObjects) throws NotSerializableException;
	public void setClassDeserialization(Class one, Class two);
}
