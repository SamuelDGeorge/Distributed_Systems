package five.serializer;

import java.io.NotSerializableException;
import java.util.List;

import util.annotations.Comp533Tags;
import util.annotations.Tags;


@Tags({Comp533Tags.VALUE_SERIALIZER})
public interface ValueSerializer{
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects) throws NotSerializableException;
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) throws NotSerializableException;
}
