package five.serializer;

import java.util.HashMap;
import java.util.Map;

import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.SERIALIZER_REGISTRY})
public class SerializerRegistry {
	private static ValueSerializer arraySerializer,beanSerializer,listPatternSerializer,enumSerializer,nullSerializer,referenceSerializer;
	private static DispatchingSerializer dispatchingSerializer;
	
	private static Map<Class,ValueSerializer> serializers = new HashMap<Class,ValueSerializer>();
	
	
	public static void registerValueSerializer(Class aClass, ValueSerializer anExternalValueSerializer) {
		serializers.put(aClass, anExternalValueSerializer);
	}
	
	public static ValueSerializer getValueSerializer(Class aClass) {
		return serializers.get(aClass);
	}
	
	public static void registerArraySerializer (ValueSerializer anExternalSerializer) {arraySerializer = anExternalSerializer;}
	public static ValueSerializer getArraySerializer() {return arraySerializer;}
	
	public static void registerBeanSerializer (ValueSerializer anExternalSerializer) {beanSerializer = anExternalSerializer;}
	public static ValueSerializer getBeanSerializer() {return beanSerializer;}
	
	public static void registerListPatternSerializer (ValueSerializer anExternalSerializer) {listPatternSerializer = anExternalSerializer;}
	public static ValueSerializer getListPatternSerializer() {return listPatternSerializer;}
	
	public static void registerEnumSerializer (ValueSerializer anExternalSerializer) {enumSerializer = anExternalSerializer;}
	public static ValueSerializer getEnumSerializer() {return enumSerializer;}
	
	public static void registerNullSerializer (ValueSerializer anExternalSerializer) {nullSerializer = anExternalSerializer;}
	public static ValueSerializer getNullSerializer() {return nullSerializer;}
	
	public static void registerDispatchingSerializer(DispatchingSerializer anExternalSerializer) {dispatchingSerializer = anExternalSerializer;}
	public static DispatchingSerializer getDispatchingSerializer() {return dispatchingSerializer;}
	
	public static void registerDeserializingClass(Class classOne, Class classTwo){
		dispatchingSerializer.setClassDeserialization(classOne, classTwo);
	}

	public static void registerReferenceSerializer(ValueSerializer anExternalSerializer) {referenceSerializer = anExternalSerializer;}
	public static ValueSerializer getReferenceSerializer() {return referenceSerializer;}
	
	
}
