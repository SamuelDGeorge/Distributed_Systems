package five.serializer;

import java.io.NotSerializableException;
import java.io.StreamCorruptedException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;

import five.valueserializers.ArraySerializer;
import five.valueserializers.BeanSerializer;
import five.valueserializers.BooleanSerializer;
import five.valueserializers.DoubleSerializer;
import five.valueserializers.EnumSerializer;
import five.valueserializers.FloatSerializer;
import five.valueserializers.HashMapSerializer;
import five.valueserializers.HashSerializer;
import five.valueserializers.HashTableSerializer;
import five.valueserializers.IntegerSerializer;
import five.valueserializers.ListPatternSerializer;
import five.valueserializers.LongSerializer;
import five.valueserializers.NullSerializer;
import five.valueserializers.ReferenceSerializer;
import five.valueserializers.ShortSerializer;
import five.valueserializers.StringSerializer;
import five.valueserializers.VectorSerializer;
import five.valueserializers.ADispatchingSerializer;
import five.valueserializers.ArrayListSerializer;
import serialization.Serializer;
import util.annotations.Comp533Tags;
import util.annotations.Tags;


@Tags({Comp533Tags.LOGICAL_BINARY_SERIALIZER})
public class BinarySerializer implements Serializer {
	private static final int MAX_BUFFER = 1000;
	private ByteBuffer toWrite;
	
	public BinarySerializer() {
		toWrite = ByteBuffer.allocate(MAX_BUFFER);
		registerSerializers();
	}
	
	//deserialize
	public Object objectFromInputBuffer(ByteBuffer inputBuffer) throws StreamCorruptedException {
		Object toReturn = null;
		
		try {
			toReturn = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(inputBuffer, new ArrayList<Object>());
			//System.out.println(inputBuffer);
		} catch (NotSerializableException e) {
			System.out.println("Object was not deSerializable!");
		}
		return toReturn;
	}

	//serialize
	public ByteBuffer outputBufferFromObject(Object object) throws NotSerializableException {
		toWrite.clear();
		SerializerRegistry.getDispatchingSerializer().objectToBuffer(toWrite, object, new ArrayList<Object>());
		
		toWrite.flip();
		//System.out.println("Final Buffer: " + new String(toWrite.array()));
		//System.out.println(toWrite.toString());
		return toWrite;
	}
	
	private void registerSerializers() {
		//Register Independent Serializers
		SerializerRegistry.registerValueSerializer(Integer.class, new IntegerSerializer());
		SerializerRegistry.registerValueSerializer(Short.class, new ShortSerializer());
		SerializerRegistry.registerValueSerializer(Long.class, new LongSerializer());
		SerializerRegistry.registerValueSerializer(Boolean.class, new BooleanSerializer());
		SerializerRegistry.registerValueSerializer(Double.class, new DoubleSerializer());
		SerializerRegistry.registerValueSerializer(Float.class, new FloatSerializer());
		SerializerRegistry.registerValueSerializer(String.class, new StringSerializer());
		SerializerRegistry.registerValueSerializer(HashSet.class, new HashSerializer());
		SerializerRegistry.registerValueSerializer(ArrayList.class, new ArrayListSerializer());
		SerializerRegistry.registerValueSerializer(Vector.class, new VectorSerializer());
		SerializerRegistry.registerValueSerializer(HashMap.class, new HashMapSerializer());
		SerializerRegistry.registerValueSerializer(Hashtable.class, new HashTableSerializer());
		
		//Register Type-Independent Serializers
		SerializerRegistry.registerArraySerializer(new ArraySerializer());
		SerializerRegistry.registerBeanSerializer(new BeanSerializer());
		SerializerRegistry.registerListPatternSerializer(new ListPatternSerializer());
		SerializerRegistry.registerEnumSerializer(new EnumSerializer());
		SerializerRegistry.registerNullSerializer(new NullSerializer());
		SerializerRegistry.registerDispatchingSerializer(new ADispatchingSerializer());
		SerializerRegistry.registerReferenceSerializer(new ReferenceSerializer());
		
		
	}


}
