package five.serializer;

import java.io.NotSerializableException;
import java.io.StreamCorruptedException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Vector;

import five.valueserializers.ArraySerializer;
import five.valueserializers.BeanSerializer;
import five.valueserializers.BooleanSerializer;
import five.stringbuffer.TrackingStringBuffer;
import five.valueserializers.ADispatchingSerializer;
import five.valueserializers.ArrayListSerializer;
import five.valueserializers.DoubleSerializer;
import five.valueserializers.EnumSerializer;
import five.valueserializers.FloatSerializer;
import five.valueserializers.HashMapSerializer;
import five.valueserializers.HashSerializer;
import five.valueserializers.HashTableSerializer;
import five.valueserializers.IntegerSerializer;
import five.valueserializers.ListPatternSerializer;
import five.valueserializers.LongSerializer;
import five.valueserializers.NullSerializer;
import five.valueserializers.ReferenceSerializer;
import five.valueserializers.ShortSerializer;
import five.valueserializers.StringSerializer;
import five.valueserializers.VectorSerializer;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import serialization.Serializer;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.LOGICAL_TEXTUAL_SERIALIZER})
public class TextualSerializer implements Serializer {
	private static final int MAX_SIZE = 10000;
	private TrackingStringBuffer serialBuffer;
	private ByteBuffer translate;
	
	public TextualSerializer() {
		this.serialBuffer = new TrackingStringBuffer();
		this.translate = ByteBuffer.allocate(MAX_SIZE);
		registerSerializers();
	}
	
	//deserialize
	public Object objectFromInputBuffer(ByteBuffer inputBuffer) throws StreamCorruptedException {
		Object toReturn = null;
		//Use the below line for Serialization Testing
		byte[] test = inputBuffer.array();
		
		//Use this line for plugging into GIPC (GIPC adds 4 bytes to the front of the buffer prior to reaching serializer)
		//byte[] test = Arrays.copyOfRange(inputBuffer.array(), 4, inputBuffer.array().length);
		
		String toProcess = new String(test);
		this.serialBuffer.setBuffer(toProcess);
		//this.serialBuffer.printBuffer();
		try {
			toReturn = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(this.serialBuffer, new ArrayList<Object>());
		} catch (NotSerializableException e) {
			System.out.println("Object was not deSerializable!");
		}
		inputBuffer.position(inputBuffer.limit());
		//System.out.println(inputBuffer);
		return toReturn;
	}

	//serialize
	public ByteBuffer outputBufferFromObject(Object object) throws NotSerializableException {
		this.serialBuffer.clear();
		this.translate.clear();
		SerializerRegistry.getDispatchingSerializer().objectToBuffer(this.serialBuffer, object, new ArrayList<Object>());
		String finishedProduct = this.serialBuffer.getBuffer().toString();
		this.serialBuffer.getBuffer().trimToSize();
		byte[] bytes = finishedProduct.getBytes();
		this.translate.put(bytes);
		ExtensibleValueSerializationFinished.newCase(this, object, this.translate, null);
		this.translate.flip();
		return this.translate;
	}


	private void registerSerializers() {
		//Register Independent Serializers
		SerializerRegistry.registerValueSerializer(Integer.class, new IntegerSerializer());
		SerializerRegistry.registerValueSerializer(Short.class, new ShortSerializer());
		SerializerRegistry.registerValueSerializer(Long.class, new LongSerializer());
		SerializerRegistry.registerValueSerializer(Boolean.class, new BooleanSerializer());
		SerializerRegistry.registerValueSerializer(Double.class, new DoubleSerializer());
		SerializerRegistry.registerValueSerializer(Float.class, new FloatSerializer());
		SerializerRegistry.registerValueSerializer(String.class, new StringSerializer());
		SerializerRegistry.registerValueSerializer(HashSet.class, new HashSerializer());
		SerializerRegistry.registerValueSerializer(ArrayList.class, new ArrayListSerializer());
		SerializerRegistry.registerValueSerializer(Vector.class, new VectorSerializer());
		SerializerRegistry.registerValueSerializer(HashMap.class, new HashMapSerializer());
		SerializerRegistry.registerValueSerializer(Hashtable.class, new HashTableSerializer());
		
		//Register Type-Independent Serializers
		SerializerRegistry.registerArraySerializer(new ArraySerializer());
		SerializerRegistry.registerBeanSerializer(new BeanSerializer());
		SerializerRegistry.registerListPatternSerializer(new ListPatternSerializer());
		SerializerRegistry.registerEnumSerializer(new EnumSerializer());
		SerializerRegistry.registerNullSerializer(new NullSerializer());
		SerializerRegistry.registerDispatchingSerializer(new ADispatchingSerializer());
		SerializerRegistry.registerReferenceSerializer(new ReferenceSerializer());
		
	}

}
