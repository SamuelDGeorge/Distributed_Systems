package five.test;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import examples.serialization.ANamedBMISpreadsheet;
import examples.serialization.AStringHistory;
import examples.serialization.AnObjectHistory;
import examples.serialization.AnotherBMISpreadsheet;
import examples.serialization.BMISpreadsheet;
import examples.serialization.NamedBMISpreadsheet;
import examples.serialization.ObjectHistory;
import examples.serialization.StringHistory;
import five.factory.ASerializerFactory;
import five.serializer.SerializerRegistry;
import port.trace.serialization.extensible.ExtensibleSerializationTraceUtility;
import serialization.Serializer;
import serialization.SerializerSelector;

public class SerializationAlternative {

	public static void main(String[] args) {
		testSerialization();
	}
	
	enum Color {RED,GREEN, BLUE}

	public static void testSerialization() {
		ExtensibleSerializationTraceUtility.setTracing();
		// part 1
		SerializerSelector.setSerializerFactory(new ASerializerFactory());
		Serializer serializer = SerializerSelector.createSerializer();
		SerializerRegistry.registerDeserializingClass(ArrayList.class, Vector.class);
		List list = new ArrayList();
		list.add("Hello world");
		list.add(3);
		list.add(Color.BLUE);
		list.add(null);
		translate(serializer, list);
		

	}

	static void translate(Serializer serializer, Object object) {
		try {
			System.out.println("Serializing " + object);
			System.out.println("Serialized Object Type: " + object.getClass());
			ByteBuffer buffer = serializer.outputBufferFromObject(object);
			Object readVal = serializer.objectFromInputBuffer(buffer);
			System.out.println("Deserialized " + readVal);
			System.out.println("Deserialized Object to Type:" + readVal.getClass());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//
	// static void testClassLoading() {
	// System.out.println( RMIClassLoader.getClassAnnotation
	// (ABMISpreadsheet.class));
	//
	// }

}
