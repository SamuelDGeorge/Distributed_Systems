package five.stringbuffer;

import java.io.StringReader;
import java.nio.ByteBuffer;

public class TrackingStringBuffer {
	private StringBuffer buffer;
	private int position;
	
	public TrackingStringBuffer() {
		this.buffer = new StringBuffer();
		this.position = 0;
	}
	
	public TrackingStringBuffer(String alreadyWritten) {
		this.buffer = new StringBuffer(alreadyWritten);
		this.position = 0;
	}
	
	public StringBuffer getBuffer() {return this.buffer;}
	
	public int getCurrentPosition() {return this.position;}
	
	public void putCharacter(char toWrite) {
		this.buffer.append(toWrite);
		this.position++;
	}
	
	public char getCharacter() {
		String singleCharacter = this.buffer.substring(position, position + 1);
		this.position++;
		char toReturn = singleCharacter.charAt(0);
		return toReturn;	
	}

	public void putInt(int intValue) {
		Integer toCalc = new Integer(intValue);
		int lengthOfInt = toCalc.toString().length();
		String frontInt = (new Integer(lengthOfInt)).toString();
		this.buffer.append(frontInt);
		this.position++;
		this.buffer.append(intValue);
		this.position = this.position + digits(toCalc.toString());
		
	}
	
	public int getInt() {
		String numberOfDigits = this.buffer.substring(this.position, this.position + 1);
		this.position++;
		int digits = Integer.parseInt(numberOfDigits);
		String number = this.buffer.substring(this.position, this.position + digits);
		this.position = this.position + digits;
		return Integer.parseInt(number);
	}
	
	public void putShort(Short currentShort) {
		Short toCalc = new Short(currentShort);
		int lengthOfShort = toCalc.toString().length();
		String frontShort = (new Integer(lengthOfShort)).toString();
		this.buffer.append(frontShort);
		this.position++;
		this.buffer.append(currentShort);
		this.position = this.position + digits(toCalc.toString());
	}
	
	public Short getShort() {
		String numberOfDigits = this.buffer.substring(this.position,this.position + 1);
		this.position++;
		int digits = Integer.parseInt(numberOfDigits);
		String number = this.buffer.substring(this.position, this.position + digits);
		this.position = this.position + digits;
		return Short.parseShort(number);
	}
	
	public void putLong(Long currentLong) {
		Long toCalc = new Long(currentLong);
		int lengthOfShort = toCalc.toString().length();
		String frontShort = (new Integer(lengthOfShort)).toString();
		this.buffer.append(frontShort);
		this.position++;
		this.buffer.append(currentLong);
		this.position = this.position + digits(toCalc.toString());
	}
	
	public Long getLong() {
		String numberOfDigits = this.buffer.substring(this.position,this.position + 1);
		this.position++;
		int digits = Integer.parseInt(numberOfDigits);
		String number = this.buffer.substring(this.position, this.position + digits);
		this.position = this.position + digits;
		return Long.parseLong(number);
	}
	
	public void putDouble(Double currentDouble) {
		Double toCalc = new Double(currentDouble);
		int lengthOfShort = toCalc.toString().length();
		String frontShort = (new Integer(lengthOfShort)).toString();
		this.buffer.append(frontShort);
		this.position++;
		this.buffer.append(currentDouble);
		this.position = this.position + digits(toCalc.toString());
		
	}
	
	public Double getDouble() {
		String numberOfDigits = this.buffer.substring(this.position,this.position + 1);
		this.position++;
		int digits = Integer.parseInt(numberOfDigits);
		String number = this.buffer.substring(this.position, this.position + digits);
		this.position = this.position + digits;
		return Double.parseDouble(number);
	}
	
	public void putFloat(Float currentFloat) {
		Float toCalc = new Float(currentFloat);
		int lengthOfShort = toCalc.toString().length();
		String frontShort = (new Integer(lengthOfShort)).toString();
		this.buffer.append(frontShort);
		this.position++;
		this.buffer.append(currentFloat);
		this.position = this.position + digits(toCalc.toString());
	}
	
	public Float getFloat() {
		String numberOfDigits = this.buffer.substring(this.position,this.position + 1);
		this.position++;
		int digits = Integer.parseInt(numberOfDigits);
		String number = this.buffer.substring(this.position, this.position + digits);
		this.position = this.position + digits;
		return Float.parseFloat(number);
	}
	
	public void put(String toAdd) {
		this.buffer.append(toAdd);
		this.position = this.position + toAdd.length();
		
	}
	
	public String get(int length) {
		String toReturn = this.buffer.substring(this.position, this.position + length);
		this.position = this.position + length;
		return toReturn;
	}
	
	public String printBuffer() {
		System.out.println(this.buffer.toString());
		return this.buffer.toString();
	}
	
	private boolean isANumber(char input) {
		if((input >= '0' && input <= '9') || input == '.') {
			return true;
		} else {
			return false;
		}
	}
	
	private int digits(String value) {
		return value.length();
	}

	public void setBuffer(String toProcess) {
		this.buffer = new StringBuffer(toProcess);
		this.position = 0;
	}

	public void clear() {
		this.buffer = new StringBuffer();
		this.position = 0;
		
	}












}
