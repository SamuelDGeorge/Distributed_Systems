package five.factory;

public class AnOutstandingReadsFactory {
	public static int getMaxReads() {
		return 900;
	}
}
