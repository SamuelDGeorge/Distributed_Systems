package five.factory;

import five.serializer.BinarySerializer;
import five.serializer.TextualSerializer;
import serialization.Serializer;
import serialization.SerializerFactory;
import util.annotations.Tags;

@Tags({})
public class ASerializerFactory implements SerializerFactory {

	public Serializer createSerializer() {
		return new TextualSerializer();
	}

}
