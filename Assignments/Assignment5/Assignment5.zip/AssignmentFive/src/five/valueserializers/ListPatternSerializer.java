package five.valueserializers;

import java.io.NotSerializableException;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;
import util.misc.RemoteReflectionUtility;

@Tags({Comp533Tags.LIST_PATTERN_SERIALIZER})
public class ListPatternSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		if(!(anObject instanceof Serializable)) {
			throw new NotSerializableException();
		}
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		@SuppressWarnings("rawtypes")
		Object list = anObject;
		visitedObjects.add(list);
		String listType = list.getClass().getName();
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(15);
			
			//Encode List type
			toManipulate.putInt(listType.length());
			byte[] toAdd = listType.getBytes();
			toManipulate.put(toAdd);
			
			//list size and put items in list
			int size = RemoteReflectionUtility.listSize(list);
			toManipulate.putInt(size);
			for (int i = 0; i < size; i++) {
				if (visitedObjects.contains(RemoteReflectionUtility.listGet(list, i))) {
					int position = visitedObjects.indexOf(RemoteReflectionUtility.listGet(list, i));
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, position, visitedObjects);
				} else {
					Object currentItem = RemoteReflectionUtility.listGet(list, i);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, currentItem, visitedObjects);
				}
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('O');
			
			//Encode List type
			toManipulate.putInt(listType.length());
			toManipulate.put(listType);
			
			//list size and put items in list
			int size = RemoteReflectionUtility.listSize(list);
			toManipulate.putInt(size);
			for (int i = 0; i < size; i++) {
				if (visitedObjects.contains(RemoteReflectionUtility.listGet(list, i))) {
					int position = visitedObjects.indexOf(RemoteReflectionUtility.listGet(list, i));
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, position, visitedObjects);
				} else {
					Object currentItem = RemoteReflectionUtility.listGet(list, i);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, currentItem, visitedObjects);
				}
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			Class type = null;
			Object toReturn = null;
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			try {
				int stringLength = toManipulate.getInt();
				byte[] stringInByteForm = new byte[stringLength];
				toManipulate.get(stringInByteForm);
				String classType = new String(stringInByteForm);
				type = Class.forName(classType);
				toReturn = type.newInstance();
				retrievedObject.add(toReturn);
				int size = toManipulate.getInt();
				for(int i = 0; i < size; i++) {
					Object toAdd = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					RemoteReflectionUtility.listAdd(toReturn, toAdd);
				}
			} catch (NotSerializableException e) {e.printStackTrace();} catch (ClassNotFoundException e) {e.printStackTrace();} catch (InstantiationException e) {
				e.printStackTrace();} catch (IllegalAccessException e) {e.printStackTrace();}
			
			Class toCheck = toReturn.getClass();
			Method method = null;
			try {
				method = toCheck.getMethod("initSerializedObject", null);
				
			} catch (NoSuchMethodException | SecurityException e) {
			}
			
			if(method != null) {
				RemoteReflectionUtility.invokeInitSerializedObject(toReturn);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			Class type = null;
			Object toReturn = null;
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			try {
				int stringLength = toManipulate.getInt();
				String classType = toManipulate.get(stringLength);
				type = Class.forName(classType);
				toReturn = type.newInstance();
				retrievedObject.add(toReturn);
				int size = toManipulate.getInt();
				for(int i = 0; i < size; i++) {
					Object toAdd = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					RemoteReflectionUtility.listAdd(toReturn, toAdd);
				}
			} catch (NotSerializableException e) {e.printStackTrace();} catch (ClassNotFoundException e) {e.printStackTrace();} catch (InstantiationException e) {
				e.printStackTrace();} catch (IllegalAccessException e) {e.printStackTrace();}
			
			Class toCheck = toReturn.getClass();
			Method method = null;
			try {
				method = toCheck.getMethod("initSerializedObject", null);
				
			} catch (NoSuchMethodException | SecurityException e) {
			}
			
			if(method != null) {
				RemoteReflectionUtility.invokeInitSerializedObject(toReturn);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	}

}
