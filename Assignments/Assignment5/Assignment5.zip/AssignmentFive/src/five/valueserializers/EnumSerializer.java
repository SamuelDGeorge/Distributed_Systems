package five.valueserializers;

import java.io.NotSerializableException;
import java.nio.ByteBuffer;
import java.util.List;

import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.ENUM_SERIALIZER})
public class EnumSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Enum enumObject = (Enum) anObject;
		String stringType = enumObject.getDeclaringClass().getName();
		String enumValue = ((Enum) anObject).toString();
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(13);
			
			toManipulate.putInt(stringType.length());
			byte[] stringI = stringType.getBytes();
			toManipulate.put(stringI);
			
			toManipulate.putInt(enumValue.length());
			byte[] string = enumValue.getBytes();
			toManipulate.put(string);
			
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('M');
			
			toManipulate.putInt(stringType.length());
			toManipulate.put(stringType);
			
			toManipulate.putInt(enumValue.length());
			toManipulate.put(enumValue);
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int typeLength = toManipulate.getInt();
			byte[] typeInByteForm = new byte[typeLength];
			toManipulate.get(typeInByteForm);
			String enumType = new String(typeInByteForm);
			
			int stringLength = toManipulate.getInt();
			byte[] stringInByteForm = new byte[stringLength];
			toManipulate.get(stringInByteForm);
			String enumValue = new String(stringInByteForm);
			
			Object toReturn = null;
			Class enumClass = null;
			
			try {
					enumClass = Class.forName(enumType);
					toReturn = Enum.valueOf(enumClass, enumValue);
			} catch (ClassNotFoundException e) {e.printStackTrace();}
				
				
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int typeLength = toManipulate.getInt();
			String enumType = toManipulate.get(typeLength);
			
			int stringLength = toManipulate.getInt();
			String enumValue = toManipulate.get(stringLength);
			
			Object toReturn = null;
			Class enumClass = null;
			
			try {
					enumClass = Class.forName(enumType);
					toReturn = Enum.valueOf(enumClass, enumValue);
			} catch (ClassNotFoundException e) {e.printStackTrace();}
			return toReturn;
		}
		
		return null;
	}

}
