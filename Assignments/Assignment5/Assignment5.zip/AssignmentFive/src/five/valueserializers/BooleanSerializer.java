package five.valueserializers;

import java.io.NotSerializableException;
import java.nio.ByteBuffer;
import java.util.List;

import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.BOOLEAN_SERIALIZER})
public class BooleanSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Boolean currentLong = (Boolean) anObject;
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(4);
			int toAdd = (currentLong)? 1:0;
			toManipulate.putInt(toAdd);
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('D');
			int toAdd = (currentLong)? 1:0;
			toManipulate.putInt(toAdd);
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int current = toManipulate.getInt();
			Boolean toReturn = (current == 1)? true:false;
			retrievedObject.add(toReturn);
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int current = toManipulate.getInt();
			Boolean toReturn = (current == 1)? true:false;
			retrievedObject.add(toReturn);
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	
	}

}
