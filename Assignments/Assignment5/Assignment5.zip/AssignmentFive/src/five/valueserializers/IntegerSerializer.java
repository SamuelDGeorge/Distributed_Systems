package five.valueserializers;

import java.io.NotSerializableException;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.util.List;

import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.INTEGER_SERIALIZER})
public class IntegerSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Integer currentInt = (Integer) anObject;
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(1);
			toManipulate.putInt(currentInt.intValue());
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer)anOutputBuffer;
			toManipulate.putCharacter('A');
			toManipulate.putInt(currentInt.intValue());
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int current = toManipulate.getInt();
			Integer toReturn = new Integer(current);
			retrievedObject.add(toReturn);
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer)anInputBuffer;
			int current = toManipulate.getInt();
			Integer toReturn = new Integer(current);
			retrievedObject.add(toReturn);
			
			return toReturn;
		}
		
		return null;
	}



}
