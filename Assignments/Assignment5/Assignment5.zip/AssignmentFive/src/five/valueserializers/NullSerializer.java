package five.valueserializers;

import java.io.NotSerializableException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.NULL_SERIALIZER})
public class NullSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);

		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(17);
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('Q');
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, Object.class);
		if(anInputBuffer instanceof ByteBuffer) {
			
		ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, null, retrievedObject);	
		return null;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
		ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, null, retrievedObject);
		return null;
		}
		
		return null;
	}

}
