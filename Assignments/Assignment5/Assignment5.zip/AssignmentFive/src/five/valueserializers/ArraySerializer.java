package five.valueserializers;

import java.io.NotSerializableException;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.List;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.ARRAY_SERIALIZER})
public class ArraySerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Class arrayType = anObject.getClass().getComponentType();
		Object[] current = (Object[]) anObject;
		visitedObjects.add(current);

		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(14);
			String className = arrayType.getName();
			byte[] toAdd = className.getBytes();
			toManipulate.putInt(className.length());
			toManipulate.put(toAdd);
			toManipulate.putInt(current.length);
			for (int i = 0; i < current.length; i++) {
				if (visitedObjects.contains(current[i])) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(current[i]), visitedObjects);
				}else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, current[i], visitedObjects);
				}
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('N');
			String className = arrayType.getName();
			toManipulate.putInt(className.length());
			toManipulate.put(className);
			toManipulate.putInt(current.length);
			for (int i = 0; i < current.length; i++) {
				if (visitedObjects.contains(current[i])) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(current[i]), visitedObjects);
				}else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, current[i], visitedObjects);
				}
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int lengthOfClassType = toManipulate.getInt();
			byte[] classBytes = new byte[lengthOfClassType];
			toManipulate.get(classBytes);
			String className = new String(classBytes);
			Class component = null;
			try {component = Class.forName(className);} catch (ClassNotFoundException e) {e.printStackTrace();}
			int length = toManipulate.getInt();
			Object array = Array.newInstance(component, length);
			retrievedObject.add(array);
			for (int i = 0; i < length; i++) {
				Object value;
				try {
					value = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					Array.set(array, i, value);
				} catch (NotSerializableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, array, retrievedObject);
			return array;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int lengthOfClassType = toManipulate.getInt();
			String className = toManipulate.get(lengthOfClassType);
			Class component = null;
			try {component = Class.forName(className);} catch (ClassNotFoundException e) {e.printStackTrace();}
			int length = toManipulate.getInt();
			Object array = Array.newInstance(component, length);
			retrievedObject.add(array);
			for (int i = 0; i < length; i++) {
				Object value;
				try {
					value = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					Array.set(array, i, value);
				} catch (NotSerializableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, array, retrievedObject);
			return array;
		}
		
		return null;
	}

}
