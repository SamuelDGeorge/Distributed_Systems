package five.valueserializers;

import java.io.NotSerializableException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.COLLECTION_SERIALIZER})
public class VectorSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		@SuppressWarnings("rawtypes")
		Vector list = (Vector) anObject;
		visitedObjects.add(anObject);
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(10);
			toManipulate.putInt(list.size());
			for (int i = 0; i < list.size(); i++) {
				Object currentItem = list.get(i);
				if (visitedObjects.contains(currentItem)) {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(currentItem), visitedObjects);
				} else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, currentItem, visitedObjects);
					visitedObjects.add(currentItem);
				}
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('J');
			toManipulate.putInt(list.size());
			for (int i = 0; i < list.size(); i++) {
				Object currentItem = list.get(i);
				if (visitedObjects.contains(currentItem)) {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(currentItem), visitedObjects);
				} else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, currentItem, visitedObjects);
					visitedObjects.add(currentItem);
				}
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			Vector toReturn = new Vector();
			retrievedObject.add(toReturn);
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int lengthOfArray = toManipulate.getInt();
			for (int i = 0; i < lengthOfArray; i++) {
				try {
					Object currentItem = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(currentItem);
					toReturn.add(currentItem);
				} catch (NotSerializableException e) {e.printStackTrace();}
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			Vector toReturn = new Vector();
			retrievedObject.add(toReturn);
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int lengthOfArray = toManipulate.getInt();
			for (int i = 0; i < lengthOfArray; i++) {
				try {
					Object currentItem = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(currentItem);
					toReturn.add(currentItem);
				} catch (NotSerializableException e) {e.printStackTrace();}
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	}

}
