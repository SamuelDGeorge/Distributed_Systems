package five.valueserializers;

import java.io.NotSerializableException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.MAP_SERIALIZER})
public class HashMapSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		HashMap map = (HashMap) anObject;
		visitedObjects.add(map);

		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(11);
			Set allKeys = map.keySet();
			toManipulate.putInt(allKeys.size());
			Iterator ite = allKeys.iterator();
			while(ite.hasNext()) {
				Object key = ite.next();
				Object value = map.get(key);
				if(visitedObjects.contains(key)) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(key), visitedObjects);
				} else {
					visitedObjects.add(key);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, key, visitedObjects);
				}
				
				if(visitedObjects.contains(value)) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(value), visitedObjects);
				} else {
					visitedObjects.add(value);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, value, visitedObjects);
				}
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('K');
			Set allKeys = map.keySet();
			toManipulate.putInt(allKeys.size());
			Iterator ite = allKeys.iterator();
			while(ite.hasNext()) {
				Object key = ite.next();
				Object value = map.get(key);
				if(visitedObjects.contains(key)) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(key), visitedObjects);
				} else {
					visitedObjects.add(key);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, key, visitedObjects);
				}
				
				if(visitedObjects.contains(value)) {
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(value), visitedObjects);
				} else {
					visitedObjects.add(value);
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, value, visitedObjects);
				}
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			HashMap toReturn = new HashMap();
			retrievedObject.add(toReturn);
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int lengthOfMap = toManipulate.getInt();
			for(int i = 0; i < lengthOfMap; i++) {
				Object key = null;
				Object value = null;
				try {
					key = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(key);
					value = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(value);
				} catch (NotSerializableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				toReturn.put(key, value);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			HashMap toReturn = new HashMap();
			retrievedObject.add(toReturn);
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int lengthOfMap = toManipulate.getInt();
			for(int i = 0; i < lengthOfMap; i++) {
				Object key = null;
				Object value = null;
				try {
					key = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(key);
					value = SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					retrievedObject.add(value);
				} catch (NotSerializableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				toReturn.put(key, value);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	}

}
