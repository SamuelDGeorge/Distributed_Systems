package five.valueserializers;

import java.io.NotSerializableException;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;

@Tags({Comp533Tags.COLLECTION_SERIALIZER})
public class ArrayListSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		@SuppressWarnings("rawtypes")
		ArrayList list = (ArrayList) anObject;
		visitedObjects.add(list);

		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(9);
			toManipulate.putInt(list.size());
			for (int i = 0; i < list.size(); i++) {
				if (visitedObjects.contains(list.get(i))) {
					int position = visitedObjects.indexOf(list.get(i));
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, position, visitedObjects);
				} else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, list.get(i), visitedObjects);
				}
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('I');
			toManipulate.putInt(list.size());
			for (int i = 0; i < list.size(); i++) {
				if (visitedObjects.contains(list.get(i))) {
					int position = visitedObjects.indexOf(list.get(i));
					SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, position, visitedObjects);
				} else {
					SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, list.get(i), visitedObjects);
				}
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
		
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, aClass);
		if(anInputBuffer instanceof ByteBuffer) {
			ArrayList toReturn = new ArrayList();
			retrievedObject.add(toReturn);
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			int lengthOfArray = toManipulate.getInt();
			for (int i = 0; i < lengthOfArray; i++) {
				try {
					toReturn.add(SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject));
				} catch (NotSerializableException e) {e.printStackTrace();}
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			ArrayList toReturn = new ArrayList();
			retrievedObject.add(toReturn);
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			int lengthOfArray = toManipulate.getInt();
			for (int i = 0; i < lengthOfArray; i++) {
				try {
					toReturn.add(SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject));
				} catch (NotSerializableException e) {e.printStackTrace();}
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	}

}
