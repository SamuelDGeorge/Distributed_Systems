package five.valueserializers;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.NotSerializableException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

import five.serializer.SerializerRegistry;
import five.serializer.ValueSerializer;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationFinished;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import serialization.Serializer;
import util.annotations.Comp533Tags;
import util.annotations.Tags;
import util.misc.RemoteReflectionUtility;

@Tags({Comp533Tags.BEAN_SERIALIZER})
public class BeanSerializer implements ValueSerializer {

	@Override
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		if(!(anObject instanceof Serializable)) {
			throw new NotSerializableException();
		}
		
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Object bean = anObject;
		visitedObjects.add(bean);
		Class beanClass = anObject.getClass();
		String beanType = bean.getClass().getName();
		if (anOutputBuffer instanceof ByteBuffer) {
			ByteBuffer toManipulate = (ByteBuffer) anOutputBuffer;
			toManipulate.putInt(16);
			//Encode bean type
			
			toManipulate.putInt(beanType.length());
			byte[] toAdd = beanType.getBytes();
			toManipulate.put(toAdd);
			
			//list size and put items in list
			BeanInfo beaninformation = null;
			try {
				beaninformation = Introspector.getBeanInfo(beanClass);
			} catch (IntrospectionException e) {e.printStackTrace();}
			
			PropertyDescriptor[] properties = beaninformation.getPropertyDescriptors();
			//System.out.println("Object Being Serialized: " + bean);
			int size = properties.length;
			for (int i = 0; i < size; i++) {
				String propertyName = properties[i].getName();
				
				Method toInvoke = properties[i].getReadMethod();
				Method toTest = properties[i].getWriteMethod();
				Object toSerialize = null;
				try {
					if(toInvoke != null && toTest != null && !RemoteReflectionUtility.isTransient(toInvoke)) {
						//System.out.println("Method Name: " + toInvoke.getName()); 
						toSerialize = toInvoke.invoke(bean, null);
						if (visitedObjects.contains(toSerialize)) {
							SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(toSerialize), visitedObjects);
						} else {
							SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, toSerialize, visitedObjects);
						}
						
					}
				} catch (IllegalAccessException e) {e.printStackTrace();} catch (IllegalArgumentException e) {e.printStackTrace();} catch (InvocationTargetException e) {e.printStackTrace();}
				
				
			}
			
		} else if (anOutputBuffer instanceof TrackingStringBuffer) {
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anOutputBuffer;
			toManipulate.putCharacter('P');
			//Encode bean type
			
			toManipulate.putInt(beanType.length());
		
			toManipulate.put(beanType);
			
			//list size and put items in list
			BeanInfo beaninformation = null;
			try {
				beaninformation = Introspector.getBeanInfo(beanClass);
			} catch (IntrospectionException e) {e.printStackTrace();}
			
			PropertyDescriptor[] properties = beaninformation.getPropertyDescriptors();
			
			int size = properties.length;
			for (int i = 0; i < size; i++) {
				String propertyName = properties[i].getName();
				Method toInvoke = properties[i].getReadMethod();
				Method toTest = properties[i].getWriteMethod();
				Object toSerialize = null;
				try {
					if(toInvoke != null && toTest != null && !RemoteReflectionUtility.isTransient(toInvoke)) {
						toSerialize = toInvoke.invoke(bean, null);
						//System.out.println(toSerialize);
						if (visitedObjects.contains(toSerialize)) {
							SerializerRegistry.getReferenceSerializer().objectToBuffer(anOutputBuffer, visitedObjects.indexOf(toSerialize), visitedObjects);
						} else {
							SerializerRegistry.getDispatchingSerializer().objectToBuffer(anOutputBuffer, toSerialize, visitedObjects);
						}
						
					}
				} catch (IllegalAccessException e) {e.printStackTrace();} catch (IllegalArgumentException e) {e.printStackTrace();} catch (InvocationTargetException e) {e.printStackTrace();}
				
				
			}
		}
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);
	}

	@Override
	public Object objectFromBuffer(Object anInputBuffer, Class aClass, List<Object> retrievedObject) {
		Class classItem = (aClass == null)? Object.class:aClass;
		ExtensibleBufferDeserializationInitiated.newCase(this, null, anInputBuffer, classItem);
		if(anInputBuffer instanceof ByteBuffer) {
			Class type = null;
			Object toReturn = null;
			ByteBuffer toManipulate = (ByteBuffer) anInputBuffer;
			try {
				int stringLength = toManipulate.getInt();
				byte[] stringInByteForm = new byte[stringLength];
				toManipulate.get(stringInByteForm);
				String classType = new String(stringInByteForm);
				type = Class.forName(classType);
				toReturn = type.newInstance();
				retrievedObject.add(toReturn);
				BeanInfo beanInformation = Introspector.getBeanInfo(type);
				PropertyDescriptor[] properties = beanInformation.getPropertyDescriptors();
				
				for(int i = 0; i < properties.length; i++) {
					Method toInvoke = properties[i].getWriteMethod();
					Method toTest = properties[i].getReadMethod();
					if(toInvoke != null && toTest != null && !RemoteReflectionUtility.isTransient(toInvoke)) {
						//System.out.println("Method Name: " + toInvoke.getName()); 
						toInvoke.invoke(toReturn, SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject));
					} else {
						//SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					}
				}
			} catch (NotSerializableException e) {e.printStackTrace();} catch (ClassNotFoundException e) {e.printStackTrace();} catch (InstantiationException e) {
				e.printStackTrace();} catch (IllegalAccessException e) {e.printStackTrace();} catch (IntrospectionException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			

			Class toCheck = toReturn.getClass();
			Method method = null;
			try {
				method = toCheck.getMethod("initSerializedObject", null);
				
			} catch (NoSuchMethodException | SecurityException e) {
			}
			
			if(method != null) {
				RemoteReflectionUtility.invokeInitSerializedObject(toReturn);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			Class type = null;
			Object toReturn = null;
			TrackingStringBuffer toManipulate = (TrackingStringBuffer) anInputBuffer;
			try {
				int stringLength = toManipulate.getInt();
				String classType = toManipulate.get(stringLength);
				type = Class.forName(classType);
				toReturn = type.newInstance();
				retrievedObject.add(toReturn);
				BeanInfo beanInformation = Introspector.getBeanInfo(type);
				PropertyDescriptor[] properties = beanInformation.getPropertyDescriptors();
				
				for(int i = 0; i < properties.length; i++) {
					Method toInvoke = properties[i].getWriteMethod();
					Method toTest = properties[i].getReadMethod();
					if(toInvoke != null && toTest != null && !RemoteReflectionUtility.isTransient(toInvoke)) {
						toInvoke.invoke(toReturn, SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject));
					} else {
						//SerializerRegistry.getDispatchingSerializer().objectFromBuffer(anInputBuffer, retrievedObject);
					}
				}
			} catch (NotSerializableException e) {e.printStackTrace();} catch (ClassNotFoundException e) {e.printStackTrace();} catch (InstantiationException e) {
				e.printStackTrace();} catch (IllegalAccessException e) {e.printStackTrace();} catch (IntrospectionException e) {
					e.printStackTrace();
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			

			Class toCheck = toReturn.getClass();
			Method method = null;
			try {
				method = toCheck.getMethod("initSerializedObject", null);
				
			} catch (NoSuchMethodException | SecurityException e) {
			}
			
			if(method != null) {
				RemoteReflectionUtility.invokeInitSerializedObject(toReturn);
			}
			
			ExtensibleBufferDeserializationFinished.newCase(this, null, anInputBuffer, toReturn, retrievedObject);
			return toReturn;
		}
		
		return null;
	}

}
