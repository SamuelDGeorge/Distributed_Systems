package five.valueserializers;

import java.beans.BeanInfo;
import java.io.NotSerializableException;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import five.serializer.SerializerRegistry;
import five.stringbuffer.TrackingStringBuffer;
import port.trace.serialization.extensible.ExtensibleBufferDeserializationInitiated;
import port.trace.serialization.extensible.ExtensibleValueSerializationFinished;
import port.trace.serialization.extensible.ExtensibleValueSerializationInitiated;
import util.annotations.Comp533Tags;
import util.annotations.Tags;
import util.misc.RemoteReflectionUtility;

@Tags({Comp533Tags.DISPATCHING_SERIALIZER})
public class ADispatchingSerializer implements five.serializer.DispatchingSerializer {
	private Map<Class,Character> classCharacterTranslations;
	private Map<Character,Class> characterClassTranslations;
	private Map<Class,Integer> classIntegerTranslations;
	private Map<Integer,Class> integerClassTranslations;
	private Map<Class,Class> alternativeDeserializations;
	
	public ADispatchingSerializer() {
		this.classCharacterTranslations = new HashMap<Class,Character>();
		this.characterClassTranslations = new HashMap<Character,Class>();
		this.classIntegerTranslations = new HashMap<Class,Integer>();
		this.integerClassTranslations = new HashMap<Integer,Class>();
		this.alternativeDeserializations = new HashMap<Class,Class>();
		populateCharacterMap(this.classCharacterTranslations,this.characterClassTranslations);
		populateIntegerMap(this.classIntegerTranslations,this.integerClassTranslations);
	}

	//Serialize
	public void objectToBuffer(Object anOutputBuffer, Object anObject, List<Object> visitedObjects)
			throws NotSerializableException {
		ExtensibleValueSerializationInitiated.newCase(this, anObject, anOutputBuffer);
		Class currentClass = (anObject == null)? null:anObject.getClass();
		if (currentClass == null) {
			SerializerRegistry.getNullSerializer().objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		} else if (currentClass.isEnum()) {
			SerializerRegistry.getEnumSerializer().objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		} else if (currentClass.isArray()) {
			SerializerRegistry.getArraySerializer().objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		}  else if (!(SerializerRegistry.getValueSerializer(currentClass) == null)) {
			SerializerRegistry.getValueSerializer(currentClass).objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		} else if (RemoteReflectionUtility.isList(currentClass)) {
			SerializerRegistry.getListPatternSerializer().objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		} else {
			SerializerRegistry.getBeanSerializer().objectToBuffer(anOutputBuffer, anObject, visitedObjects);
		}
		//((TrackingStringBuffer)anOutputBuffer).printBuffer();
		ExtensibleValueSerializationFinished.newCase(this, anObject, anOutputBuffer, visitedObjects);

	}

	//Deserialize
	public Object objectFromBuffer(Object anInputBuffer, List<Object> retrievedObjects)
			throws NotSerializableException {
	
		if(anInputBuffer instanceof ByteBuffer) {
			return deserializeByteBuffer(anInputBuffer, retrievedObjects);
		} else if (anInputBuffer instanceof TrackingStringBuffer) {
			//((TrackingStringBuffer)anInputBuffer).printBuffer();
			return deserializeStringBuffer(anInputBuffer,retrievedObjects);
		}
		

		return null;
	}

	private Object deserializeStringBuffer(Object anInputBuffer, List<Object> retrievedObjects) throws NotSerializableException {
		char firstChar = ((TrackingStringBuffer)anInputBuffer).getCharacter();
		firstChar = translateForDeserializing(firstChar);
		
		if(firstChar == 'A') {
			return SerializerRegistry.getValueSerializer(Integer.class).objectFromBuffer(anInputBuffer, Integer.class, retrievedObjects);
		} else if (firstChar == 'B') {
			return SerializerRegistry.getValueSerializer(Short.class).objectFromBuffer(anInputBuffer, Short.class, retrievedObjects);
		} else if (firstChar == 'C') {
			return SerializerRegistry.getValueSerializer(Long.class).objectFromBuffer(anInputBuffer, Long.class, retrievedObjects);
		} else if (firstChar == 'D') {
			return SerializerRegistry.getValueSerializer(Boolean.class).objectFromBuffer(anInputBuffer, Boolean.class, retrievedObjects);
		} else if (firstChar == 'E') {
			return SerializerRegistry.getValueSerializer(Double.class).objectFromBuffer(anInputBuffer, Double.class, retrievedObjects);
		} else if (firstChar == 'F') {
			return SerializerRegistry.getValueSerializer(Float.class).objectFromBuffer(anInputBuffer, Float.class, retrievedObjects);
		} else if (firstChar == 'G') {
			return SerializerRegistry.getValueSerializer(String.class).objectFromBuffer(anInputBuffer, String.class, retrievedObjects);
		} else if (firstChar == 'H') {
			return SerializerRegistry.getValueSerializer(HashSet.class).objectFromBuffer(anInputBuffer, HashSet.class, retrievedObjects);
		} else if (firstChar == 'I') {
			return SerializerRegistry.getValueSerializer(ArrayList.class).objectFromBuffer(anInputBuffer, ArrayList.class, retrievedObjects);
		} else if (firstChar == 'J') {
			return SerializerRegistry.getValueSerializer(Vector.class).objectFromBuffer(anInputBuffer, Vector.class, retrievedObjects);
		} else if (firstChar == 'K') {
			return SerializerRegistry.getValueSerializer(HashMap.class).objectFromBuffer(anInputBuffer, HashMap.class, retrievedObjects);
		} else if (firstChar == 'L') {
			return SerializerRegistry.getValueSerializer(Hashtable.class).objectFromBuffer(anInputBuffer, Hashtable.class, retrievedObjects);
		} else if (firstChar == 'M') {
			return SerializerRegistry.getEnumSerializer().objectFromBuffer(anInputBuffer, Enum.class, retrievedObjects);
		} else if (firstChar == 'N') {
			return SerializerRegistry.getArraySerializer().objectFromBuffer(anInputBuffer, Array.class, retrievedObjects);
		} else if (firstChar == 'O') {
			return SerializerRegistry.getListPatternSerializer().objectFromBuffer(anInputBuffer, List.class, retrievedObjects);
		} else if (firstChar == 'P') {
			return SerializerRegistry.getBeanSerializer().objectFromBuffer(anInputBuffer, null, retrievedObjects);
		} else if (firstChar == 'Q'){
			return SerializerRegistry.getNullSerializer().objectFromBuffer(anInputBuffer, null, retrievedObjects);
		} else if  (firstChar == 'R') {
			return SerializerRegistry.getReferenceSerializer().objectFromBuffer(anInputBuffer,null,retrievedObjects);
		} else {	
			throw new NotSerializableException("Failed to find serialization class");
		}
	}


	private char translateForDeserializing(char firstChar) {
		Class toDeserialize = this.characterClassTranslations.get(firstChar);
		if (this.alternativeDeserializations.get(toDeserialize) == null) {
			return firstChar;
		} else {
			Class toTranformTo = this.alternativeDeserializations.get(toDeserialize);
			Character toReturn = this.classCharacterTranslations.get(toTranformTo);
			return toReturn;
		}
	}

	private void populateCharacterMap(Map<Class, Character> classCharacterTranslations2, Map<Character, Class> integerClassTranslations2) {
		classCharacterTranslations2.put(Integer.class, 'A');
		classCharacterTranslations2.put(Short.class, 'B');
		classCharacterTranslations2.put(Long.class, 'C');
		classCharacterTranslations2.put(Boolean.class, 'D');
		classCharacterTranslations2.put(Double.class, 'E');
		classCharacterTranslations2.put(Float.class, 'F');
		classCharacterTranslations2.put(String.class, 'G');
		classCharacterTranslations2.put(HashSet.class, 'H');
		classCharacterTranslations2.put(ArrayList.class, 'I');
		classCharacterTranslations2.put(Vector.class, 'J');
		classCharacterTranslations2.put(HashMap.class, 'K');
		classCharacterTranslations2.put(Hashtable.class, 'L');	
		
		integerClassTranslations2.put('A', Integer.class);
		integerClassTranslations2.put('B', Short.class);
		integerClassTranslations2.put('C', Long.class);
		integerClassTranslations2.put('D', Boolean.class);
		integerClassTranslations2.put('E', Double.class);
		integerClassTranslations2.put('F', Float.class);
		integerClassTranslations2.put('G', String.class);
		integerClassTranslations2.put('H', HashSet.class);
		integerClassTranslations2.put('I', ArrayList.class);
		integerClassTranslations2.put('J', Vector.class);
		integerClassTranslations2.put('K', HashMap.class);
		integerClassTranslations2.put('L', Hashtable.class);
	}
	

	private Object deserializeByteBuffer(Object anInputBuffer, List<Object> retrievedObjects) throws NotSerializableException {
		int currentByte = ((ByteBuffer) anInputBuffer).getInt();
		currentByte = translateForDeserializing(currentByte);
		if(currentByte == 1) {
			return SerializerRegistry.getValueSerializer(Integer.class).objectFromBuffer(anInputBuffer, Integer.class, retrievedObjects);
		} else if (currentByte == 2) {
			return SerializerRegistry.getValueSerializer(Short.class).objectFromBuffer(anInputBuffer, Short.class, retrievedObjects);
		} else if (currentByte == 3) {
			return SerializerRegistry.getValueSerializer(Long.class).objectFromBuffer(anInputBuffer, Long.class, retrievedObjects);
		} else if (currentByte == 4) {
			return SerializerRegistry.getValueSerializer(Boolean.class).objectFromBuffer(anInputBuffer, Boolean.class, retrievedObjects);
		} else if (currentByte == 5) {
			return SerializerRegistry.getValueSerializer(Double.class).objectFromBuffer(anInputBuffer, Double.class, retrievedObjects);
		} else if (currentByte == 6) {
			return SerializerRegistry.getValueSerializer(Float.class).objectFromBuffer(anInputBuffer, Float.class, retrievedObjects);
		} else if (currentByte == 7) {
			return SerializerRegistry.getValueSerializer(String.class).objectFromBuffer(anInputBuffer, String.class, retrievedObjects);
		} else if (currentByte == 8) {
			return SerializerRegistry.getValueSerializer(HashSet.class).objectFromBuffer(anInputBuffer, HashSet.class, retrievedObjects);
		} else if (currentByte == 9) {
			return SerializerRegistry.getValueSerializer(ArrayList.class).objectFromBuffer(anInputBuffer, ArrayList.class, retrievedObjects);
		} else if (currentByte == 10) {
			return SerializerRegistry.getValueSerializer(Vector.class).objectFromBuffer(anInputBuffer, Vector.class, retrievedObjects);
		} else if (currentByte == 11) {
			return SerializerRegistry.getValueSerializer(HashMap.class).objectFromBuffer(anInputBuffer, HashMap.class, retrievedObjects);
		} else if (currentByte == 12) {
			return SerializerRegistry.getValueSerializer(Hashtable.class).objectFromBuffer(anInputBuffer, Hashtable.class, retrievedObjects);
		} else if (currentByte == 13) {
			return SerializerRegistry.getEnumSerializer().objectFromBuffer(anInputBuffer, Enum.class, retrievedObjects);
		} else if (currentByte == 14) {
			return SerializerRegistry.getArraySerializer().objectFromBuffer(anInputBuffer, Array.class, retrievedObjects);
		} else if (currentByte == 15) {
			return SerializerRegistry.getListPatternSerializer().objectFromBuffer(anInputBuffer, List.class, retrievedObjects);
		} else if (currentByte == 16) {
			return SerializerRegistry.getBeanSerializer().objectFromBuffer(anInputBuffer, null, retrievedObjects);
		} else if (currentByte == 17){
			return SerializerRegistry.getNullSerializer().objectFromBuffer(anInputBuffer, null, retrievedObjects);
		} else if  (currentByte == 18) {
			return SerializerRegistry.getReferenceSerializer().objectFromBuffer(anInputBuffer,null,retrievedObjects);
		} else {	
			throw new NotSerializableException("Failed to find serialization class");
		}
		
		
	}
	
	private int translateForDeserializing(int currentByte) {
		Class toDeserialize = this.integerClassTranslations.get(currentByte);
		if (this.alternativeDeserializations.get(toDeserialize) == null) {
			return currentByte;
		} else {
			Class toTranformTo = this.alternativeDeserializations.get(toDeserialize);
			int toReturn = this.classIntegerTranslations.get(toTranformTo);
			return toReturn;
		}
	}

	private void populateIntegerMap(Map<Class, Integer> classCharacterTranslations2, Map<Integer, Class> integerClassTranslations2) {
		classCharacterTranslations2.put(Integer.class, 1);
		classCharacterTranslations2.put(Short.class, 2);
		classCharacterTranslations2.put(Long.class, 3);
		classCharacterTranslations2.put(Boolean.class, 4);
		classCharacterTranslations2.put(Double.class, 5);
		classCharacterTranslations2.put(Float.class, 6);
		classCharacterTranslations2.put(String.class, 7);
		classCharacterTranslations2.put(HashSet.class, 8);
		classCharacterTranslations2.put(ArrayList.class, 9);
		classCharacterTranslations2.put(Vector.class, 10);
		classCharacterTranslations2.put(HashMap.class, 11);
		classCharacterTranslations2.put(Hashtable.class, 12);
		
		integerClassTranslations2.put(1, Integer.class);
		integerClassTranslations2.put(2, Short.class);
		integerClassTranslations2.put(3, Long.class);
		integerClassTranslations2.put(4, Boolean.class);
		integerClassTranslations2.put(5, Double.class);
		integerClassTranslations2.put(6, Float.class);
		integerClassTranslations2.put(7, String.class);
		integerClassTranslations2.put(8, HashSet.class);
		integerClassTranslations2.put(9, ArrayList.class);
		integerClassTranslations2.put(10, Vector.class);
		integerClassTranslations2.put(11, HashMap.class);
		integerClassTranslations2.put(12, Hashtable.class);
		
		
	}
	
	
	public void setClassDeserialization(Class one, Class two) {
		this.alternativeDeserializations.put(one, two);
	}

}
