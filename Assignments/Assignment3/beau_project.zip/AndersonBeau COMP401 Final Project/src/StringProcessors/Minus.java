package StringProcessors;

public class Minus extends Number
{
	public Minus(String input)
	{
		super(input, "Minus Number");
	}
}