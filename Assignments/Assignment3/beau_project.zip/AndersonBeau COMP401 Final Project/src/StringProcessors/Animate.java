package StringProcessors;

public class Animate extends Word
{
	public Animate(String input)
	{
		super(input, "Command");
	}
}