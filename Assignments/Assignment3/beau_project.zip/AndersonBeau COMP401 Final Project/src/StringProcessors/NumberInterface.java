package StringProcessors;

public interface NumberInterface extends TokenInterface
{
	public int convertToInt();
}
