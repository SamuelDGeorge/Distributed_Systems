package StringProcessors;

public class Assign extends Word
{
	public Assign(String input)
	{
		super(input, "Command");
	}
}