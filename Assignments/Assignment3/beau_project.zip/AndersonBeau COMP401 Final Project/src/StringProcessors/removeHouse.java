package StringProcessors;

public class removeHouse extends Word
{
	public removeHouse(String input)
	{
		super(input, "Command");
	}
}