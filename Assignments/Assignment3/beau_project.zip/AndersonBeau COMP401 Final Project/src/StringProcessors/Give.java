package StringProcessors;

public class Give extends Word
{
	public Give(String input)
	{
		super(input, "Command");
	}
}