package Graphics;

public interface CompleteHouseWithCandyCollection extends LabelCollection<CompleteHouseWithCandy>
{

}
