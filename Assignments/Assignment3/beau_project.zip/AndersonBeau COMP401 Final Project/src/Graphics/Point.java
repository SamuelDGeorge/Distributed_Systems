package Graphics;

public interface Point
{
	public int getX(); 
	public int getY(); 	
}
