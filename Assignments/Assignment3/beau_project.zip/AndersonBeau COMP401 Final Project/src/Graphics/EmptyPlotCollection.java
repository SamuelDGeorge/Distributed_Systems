package Graphics;

public interface EmptyPlotCollection extends LabelCollection<EmptyPlot>
{

}
