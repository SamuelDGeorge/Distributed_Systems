package Graphics;

public class ALine extends AShape
{
	public ALine(int initX, int initY, int initWidth, int initHeight)
	{
		super(initX, initY, initWidth, initHeight);
	}
}
