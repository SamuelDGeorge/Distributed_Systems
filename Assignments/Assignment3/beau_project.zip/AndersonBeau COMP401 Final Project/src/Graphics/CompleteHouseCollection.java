package Graphics;

public interface CompleteHouseCollection extends LabelCollection<CompleteHouse>
{

}
