package three.clients;

import java.io.IOException;

public interface BeauNIOClient {
	public void setBroadcastMode(String input);
	public void doCommand(String command) throws IOException;
}
