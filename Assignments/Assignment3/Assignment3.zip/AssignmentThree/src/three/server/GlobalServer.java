package three.server;

public interface GlobalServer {
	public void setSynchronizedResponse(boolean value);
}
